# BuildSmart: AI-designed, website-based Construction Management

Three logins on the home page (**User**, **Contractor**, **Admin**). The designer and worker roles are gone:
an **AI plan designer** now makes the floor plan, and the contractor posts the daily updates.

## 1. One-time setup
1. **Database** (phpMyAdmin -> `construction_management` -> SQL tab). Run each file **once**, in this order (a "Duplicate column" error just means that one already ran; move to the next file):
   1. `sql/smartbuild_schema.sql`
   2. `sql/smartbuild_schema_v2.sql` (payment method / reference columns)
   3. `sql/smartbuild_schema_v3.sql` (**new**: labour/material charge columns)
   This is not optional: the payment pages now query every column on `tbl_weekly_payments`, so skipping v2 or v3 breaks pay, receipts, the project page and the admin page, not just the new features. Check with `SHOW COLUMNS FROM tbl_weekly_payments;` — you should see `method, txn_ref, paid_at, category, label`.
2. `python -m pip install -r requirements-smartbuild.txt`
3. **Optional free AI summaries** (Hugging Face): create a free token at huggingface.co (Settings -> Access Tokens, tick "Make calls to Inference Providers") and run `set HF_TOKEN=hf_xxxx` before starting the server. Without it, everything works; updates just have no English summary.
4. `python manage.py runserver`, then open **http://127.0.0.1:8000/** (use 127.0.0.1 or localhost so the microphone works). Use Chrome or Edge.

## 2. Logging in (this also fixes the wrong-password error)
The old `/` login looked up designers after a failed admin login and could end on an error page. Login is now one form on the home page:
- **User:** phone or email + password (register on the site).
- **Contractor:** phone or email + password. The admin creates contractors (sidebar -> Contractor).
- **Admin:** email + password. The account must be a **superuser** (the admin sidebar only shows for superusers). If yours is not: `python manage.py createsuperuser`.
A wrong password now shows "Wrong phone/email or password." on the same page. No crash.

## 3. Demo walkthrough
| Step | Who | Action |
|---|---|---|
| 1 | Admin | Log in on the home page, open **Contractor** in the sidebar and add a contractor |
| 2 | Anyone | On the home page, set rooms and area in **AI plan designer**: floor plan and cost estimate appear instantly; **Try another layout** gives variations |
| 3 | User | **Use this design**, register or log in, enter the budget, choose a contractor, **Create project** |
| 4 | User | On the project page review the plan (or **Try another layout**), then **Accept this plan** |
| 5 | Contractor | Log in, open the project, **Create payment stages** |
| 6 | Contractor | **Daily updates**: type, or Start speaking (Malayalam), then Post |
| 7 | Contractor | **Mark complete** on a stage (needs an update for that stage first) |
| 8 | User | **Approve** the stage, then **Pay now**: choose UPI / Card / Net banking, then the **receipt** page |
| 9 | Admin | Sidebar **Payments** and **Milestones & Estimates** list stages, estimates and payments (method + reference) |

## 4. What the "AI" really is (say this in the viva)
- **Plan designer:** a *rule-based generative layout algorithm* (room programme, zoning, squarified treemap packing). It is **not** a trained neural network. It is tested: for 4,000+ random requests every plan tiled its floor exactly, had no overlapping rooms and the right number of bedrooms/bathrooms, and stairs lined up between floors. Impossible requests (for example 6 bedrooms in 600 sq ft) are refused with a reason. The plans are **concept sketches, not approved drawings**: an architect must prepare real drawings. The site says so.
- **Cost estimate:** Random Forest trained on **synthetic data** from my placeholder rates (`smartbuild/services/datagen.py`). Its scores only show the pipeline works. For real accuracy, put 100+ real project costs in `sql/projects_template.csv` and run `python manage.py train_estimator --csv sql/projects_template.csv`.
- **Voice:** your browser's speech recognition (Chrome/Edge). Malayalam quality is Google's; the text stays editable.
- **Summaries:** a Hugging Face model (free tier, default `Qwen/Qwen3-8B`, change with `SMARTBUILD_SUMMARY_MODEL`). Text is sent to Hugging Face when a token is set.
- **Payments are a DEMO checkout:** the buttons record a payment with a method and reference and print a receipt, but **no money moves and no card details are collected**. To take real payments, connect a gateway (for example Razorpay or PayU in test mode, which need their own keys) inside `payment_pay` in `smartbuild/views.py`.

## 5. Known gaps (please read)
- **I could not run Django here.** The logic has 29 passing tests and every file compiles with no undefined names, but the views and templates have never been executed. Expect a small bug or two on first run; paste any error and I will fix it. I have also not seen the pages in a browser, only checked the plan geometry.
- Old projects created in the designer era (status Pending/Accepted) cannot progress now. Ignore them or start new projects.
- The `/api/plan/generate/` endpoint is public and has no rate limiting.
- Existing admin pages (dashboard, users, payments) still have no login check, and passwords created by admin forms are plain text. Fix both before real use. New user accounts are hashed.
- Designer and worker tables stay in the database, unused.
- Not implemented: password reset, email/SMS, rate-limiting logins, refunds.


## 6. This update: two bugs fixed, one feature added
- **"window.api is not a function" on the home page.** `home.html` replaces the part of the page template that came *before* the script defining `window.api`, so the AI designer tried to call it before it existed. The script now loads immediately after `<body>`, before anything else runs. If you still see this error, hard-refresh (Ctrl+F5) so the browser drops the cached page.
- **Admin "Milestones & Estimates" page erroring.** Almost certainly `sql/smartbuild_schema_v2.sql` had not been run, so the payments table was missing columns the page needed. The page now shows a yellow warning naming the missing table/column instead of failing outright, but you still need to run the SQL files for payments to actually work.
- **Labour / material charges.** Milestone stages are fixed amounts for the 5 standard stages. For anything else — paying workers for a specific task, buying materials — the contractor can now raise a one-off charge on the project page ("Add a labour / material charge": a short description and an amount). It appears in the client's payment list labelled "Labour/material", and is paid the same way as a stage (Pay now -> receipt). Needs `schema_v3.sql`.

## 7. New admin look
`static/css/buildsmart-admin.css` reskins the existing admin dashboard (sidebar, buttons, cards, tables) in the same yellow/charcoal palette as the public site, without changing any page's structure. It's linked from `templates/base.html` after the original theme CSS, so it only overrides colours and does not remove any existing styling. If a page looks unstyled after update, hard-refresh to clear the cached CSS.
