"""Website for clients and contractors (admin logs in here too, then uses the admin panel).

Flow: the client designs a house with the AI plan generator, picks a contractor and
sends the project (status 'Plan Submitted') -> accepts the plan ('Plan Accepted') ->
the contractor creates milestones, posts daily updates and completes them -> the client
approves each milestone and pays -> 'Completed' after the last approval.

Business rules (estimates, milestones, payments, daily updates, plan generation) live
in the JSON API in smartbuild/; these pages call it with a short-lived token so there
is one implementation of each rule.
"""
import functools
import logging
import os
import random
import uuid
from types import SimpleNamespace
from urllib.parse import quote

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.validators import validate_email
from django.db.models import Q
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from login.models import (Contractors, PlanDailyUpdates, ProjectRequirements, TableUser, WeeklyPayments)
from smartbuild.errors import ApiError
from smartbuild.models import CostEstimate, Milestone
from smartbuild.services import estimator, planner
from smartbuild.services.passwords import verify_password
from smartbuild.services.tokens import make_token
from smartbuild.validation import parse_int, parse_money, parse_spec

logger = logging.getLogger(__name__)

# portal role -> (model, role name used by the API, home url name)
ROLES = {
    'client': (TableUser, 'user', 'portal_client'),
    'contractor': (Contractors, 'contractor', 'portal_contractor'),
}
LOGIN_ROLES = ('client', 'contractor', 'admin')
ROLE_LABELS = {'client': 'Client', 'contractor': 'Contractor', 'admin': 'Admin'}
PAGE_TOKEN_TTL = 8 * 3600
ACTIVE_STATUSES = ('Plan Submitted', 'Plan Accepted')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg')
PAY_METHOD_LABELS = {'upi': 'UPI', 'card': 'Card', 'netbanking': 'Net banking'}


# ------------------------------------------------------------------ helpers
def portal_login_required(*roles):
    def decorator(view):
        @functools.wraps(view)
        def wrapper(request, *args, **kwargs):
            who = request.session.get('portal')
            if not who:
                return redirect('%s?next=%s' % (reverse('portal_login'), quote(request.get_full_path())))
            if roles and who['role'] not in roles:
                messages.error(request, 'That page is not available for your account type.')
                return redirect(ROLES[who['role']][2])
            request.who = SimpleNamespace(**who)
            return view(request, *args, **kwargs)
        return wrapper
    return decorator


def page(request, template, context=None, status=200):
    """render() plus the identity and short-lived API token every page needs."""
    ctx = dict(context or {})
    who = getattr(request, 'who', None)
    if who is not None:
        ctx['who'] = who
        ctx['role_label'] = ROLE_LABELS[who.role]
        ctx['api_token'] = make_token({'role': ROLES[who.role][1], 'id': who.id, 'name': who.name},
                                      settings.SECRET_KEY, PAGE_TOKEN_TTL)
    return render(request, template, ctx, status=status)


def _public(request, template, context=None):
    """Pages that anyone can open; still shows the right nav if someone is logged in."""
    ctx = dict(context or {})
    ctx['who'] = request.session.get('portal')
    ctx['is_admin'] = request.user.is_authenticated and request.user.is_superuser
    return render(request, template, ctx)


def _names(model):
    return {str(o.id): o.name for o in model.objects.all()}


def _plan_info(req):
    url, is_image = None, False
    if req.plan_file:
        try:
            url = req.plan_file.url
            is_image = os.path.splitext(str(req.plan_file.name))[1].lower() in IMAGE_EXTENSIONS
        except ValueError:
            pass
    return url, is_image


def _progress(milestones):
    return int(sum(float(m.percent_of_cost) for m in milestones if m.status == 'Approved'))


def _can_access(who, req):
    if who.role == 'client':
        return str(req.user_id) == str(who.id)
    return str(req.contractor_id) == str(who.id)


def _get_req(rid):
    return ProjectRequirements.objects.filter(pk=rid).first()


def _save_plan_svg(plan):
    return default_storage.save('plan/ai_plan_%s.svg' % uuid.uuid4().hex[:12],
                                ContentFile(planner.render_svg(plan).encode('utf-8')))


def _plan_label(plan):
    s = plan['specs']
    return 'AI plan: %dBR / %dBA / %d floor(s) / %d sq ft (layout %d)' % (
        s['bedrooms'], s['bathrooms'], s['stories'], s['total_sq_ft'], plan['seed'])


# ------------------------------------------------------------- public pages
def home(request):
    return _public(request, 'portal/home.html', {'role': 'client'})


def login_view(request):
    role = request.POST.get('role') or request.GET.get('role') or 'client'
    if role not in LOGIN_ROLES:
        role = 'client'
    if request.method == 'POST':
        identifier = (request.POST.get('identifier') or '').strip()
        password = request.POST.get('password') or ''
        if role == 'admin':
            user = authenticate(request, email=identifier, password=password) if identifier and password else None
            if user is not None and user.is_superuser:
                auth_login(request, user)
                return redirect('dashboard')
            messages.error(request, 'Wrong email or password.')
        else:
            account = None
            if identifier and password:
                for candidate in ROLES[role][0].objects.filter(Q(phone=identifier) | Q(email__iexact=identifier))[:5]:
                    if verify_password(password, candidate.password):
                        account = candidate
                        break
            if account is None:
                messages.error(request, 'Wrong phone/email or password.')
            else:
                request.session.cycle_key()
                request.session['portal'] = {'role': role, 'id': account.id, 'name': account.name}
                target = request.POST.get('next') or ''
                if target and url_has_allowed_host_and_scheme(target, allowed_hosts={request.get_host()}):
                    return redirect(target)
                return redirect(ROLES[role][2])
    return _public(request, 'portal/login.html', {
        'role': role, 'role_label': ROLE_LABELS[role], 'next': request.GET.get('next', request.POST.get('next', ''))})


def logout_view(request):
    auth_logout(request)           # clears the whole session (portal login and admin login)
    messages.success(request, 'You have been logged out.')
    return redirect('home')


def register(request):
    form = {}
    if request.method == 'POST':
        form = {k: (request.POST.get(k) or '').strip() for k in ('name', 'email', 'phone')}
        password, confirm = request.POST.get('password') or '', request.POST.get('confirm') or ''
        error = None
        try:
            validate_email(form['email'])
        except ValidationError:
            error = 'Enter a valid email address.'
        if not form['name']:
            error = 'Name is required.'
        elif not (form['phone'].isdigit() and len(form['phone']) == 10):
            error = 'Phone must be exactly 10 digits.'
        elif len(password) < 6:
            error = 'Password must be at least 6 characters.'
        elif password != confirm:
            error = 'Passwords do not match.'
        elif TableUser.objects.filter(Q(phone=form['phone']) | Q(email__iexact=form['email'])).exists():
            error = 'An account with this phone or email already exists.'
        if error:
            messages.error(request, error)
        else:
            user = TableUser.objects.create(
                name=form['name'], email=form['email'], phone=form['phone'],
                password=make_password(password), created_at=timezone.now())
            request.session.cycle_key()
            request.session['portal'] = {'role': 'client', 'id': user.id, 'name': user.name}
            messages.success(request, 'Welcome! Your account is ready.')
            return redirect('portal_client')
    return _public(request, 'portal/register.html', {'form': form})


# ------------------------------------------------------------------- client
@portal_login_required('client')
def client_dashboard(request):
    reqs = list(ProjectRequirements.objects.filter(user_id=str(request.who.id)).order_by('-id'))
    contractors = _names(Contractors)
    ids = [r.id for r in reqs]
    by_req = {}
    for m in Milestone.objects.filter(requirement_id__in=ids):
        by_req.setdefault(m.requirement_id, []).append(m)
    estimates = {}
    for e in CostEstimate.objects.filter(requirement_id__in=ids).order_by('id'):
        estimates[e.requirement_id] = e   # later rows overwrite earlier: newest wins
    rows = [{
        'req': r, 'contractor': contractors.get(str(r.contractor_id), '-'),
        'estimate': estimates.get(r.id), 'progress': _progress(by_req.get(r.id, [])),
        'has_milestones': r.id in by_req} for r in reqs]
    due = list(WeeklyPayments.objects.filter(plan_id__in=[str(i) for i in ids], status='pending').order_by('-id'))
    return page(request, 'portal/dashboard_client.html', {
        'rows': rows, 'due': due, 'due_total': sum(float(p.amount) for p in due)})


@portal_login_required('client')
def client_new_requirement(request):
    contractors = list(Contractors.objects.all().order_by('name'))
    form = request.GET.dict()
    if request.method == 'POST':
        form = request.POST.dict()
        try:
            spec = parse_spec(form)
            budget = parse_money(form.get('budget'), 'budget')
            seed = parse_int(form.get('seed'), 'seed', 0, 2 ** 31 - 1, required=False) or random.randint(1, 999999)
            contractor = Contractors.objects.filter(pk=form.get('contractor') or 0).first()
            if contractor is None:
                raise ApiError(400, 'Please choose a contractor.')
            try:
                plan = planner.generate_robust(seed=seed, **spec)
            except planner.PlanError as exc:
                raise ApiError(422, str(exc))
        except ApiError as exc:
            messages.error(request, exc.message)
        else:
            now = timezone.now()
            req = ProjectRequirements.objects.create(
                user_id=str(request.who.id), designer_id=None, contractor_id=str(contractor.id),
                bedrooms=str(spec['bedrooms']), bathrooms=str(spec['bathrooms']), garage=str(spec['garage']),
                stories=str(spec['stories']), total_sq_ft=str(spec['total_sq_ft']),
                requirement_status='Plan Submitted', plan_name=_plan_label(plan)[:100],
                plan_file=_save_plan_svg(plan), budget=str(int(budget)), created_at=now, updated_at=now)
            try:   # the estimate is a bonus; never block saving the project because of it
                result = estimator.estimate(budget=budget, **spec)
                f = result['feasibility']
                CostEstimate.objects.create(
                    requirement_id=req.id, user_id=request.who.id, budget=budget,
                    predicted_cost=result['predicted_cost'], min_cost=result['min_cost'], max_cost=result['max_cost'],
                    feasibility=f['status'], feasibility_note=f['note'][:500],
                    suggested_sq_ft=f['suggested_sq_ft'], model_version=result['model']['version'])
            except Exception:
                logger.exception('Could not save cost estimate for requirement %s', req.id)
            messages.success(request, 'Project created. Review the plan, then accept it to start the work.')
            return redirect('portal_project', rid=req.id)
    return page(request, 'portal/new_requirement.html', {'contractors': contractors, 'form': form})


@portal_login_required('client')
def client_contractors(request):
    done = {}
    for r in ProjectRequirements.objects.filter(requirement_status='Completed'):
        done[str(r.contractor_id)] = done.get(str(r.contractor_id), 0) + 1
    cards = [{'contractor': c, 'completed': done.get(str(c.id), 0)} for c in Contractors.objects.all().order_by('name')]
    return page(request, 'portal/contractors.html', {'cards': cards})


@require_POST
@portal_login_required('client')
def client_accept_plan(request, rid):
    req = _get_req(rid)
    if req is None or str(req.user_id) != str(request.who.id):
        messages.error(request, 'Project not found.')
        return redirect('portal_client')
    changed = ProjectRequirements.objects.filter(pk=rid, requirement_status='Plan Submitted').update(
        requirement_status='Plan Accepted')
    if changed:
        messages.success(request, 'Plan accepted. The contractor can now start the work.')
    else:
        messages.error(request, 'There is no submitted plan to accept.')
    return redirect('portal_project', rid=rid)


@require_POST
@portal_login_required('client')
def client_regenerate_plan(request, rid):
    """'Try another layout': replace the AI plan while it is still awaiting acceptance."""
    req = _get_req(rid)
    if req is None or str(req.user_id) != str(request.who.id) or req.requirement_status != 'Plan Submitted':
        messages.error(request, 'A new layout can only be made before you accept the plan.')
        return redirect('portal_client')
    try:
        spec = parse_spec({'bedrooms': req.bedrooms, 'bathrooms': req.bathrooms, 'stories': req.stories,
                           'garage': req.garage, 'total_sq_ft': req.total_sq_ft})
        plan = planner.generate_robust(seed=random.randint(1, 999999), **spec)
    except (ApiError, planner.PlanError) as exc:
        messages.error(request, getattr(exc, 'message', None) or str(exc))
        return redirect('portal_project', rid=rid)
    old = str(req.plan_file.name) if req.plan_file else ''
    new_name = _save_plan_svg(plan)
    changed = ProjectRequirements.objects.filter(pk=rid, requirement_status='Plan Submitted').update(
        plan_file=new_name, plan_name=_plan_label(plan)[:100])
    if changed and old.startswith('plan/ai_plan_'):
        default_storage.delete(old)
    messages.success(request, 'Here is a new layout.')
    return redirect('portal_project', rid=rid)


# ---------------------------------------------------------------- payments
def _payment_for(request, pid, need_status):
    """Return (payment, requirement) if the logged-in person may see it, else (None, None)."""
    payment = WeeklyPayments.objects.filter(pk=pid).first()
    if payment is None or payment.status != need_status:
        return None, None
    try:
        req = _get_req(int(payment.plan_id))
    except ValueError:
        return None, None
    if req is None or not _can_access(request.who, req):
        return None, None
    return payment, req


@portal_login_required('client')
def pay_page(request, pid):
    payment, req = _payment_for(request, pid, 'pending')
    if payment is None:
        messages.error(request, 'That payment is not available (it may already be paid).')
        return redirect('portal_client')
    milestone = Milestone.objects.filter(pk=payment.milestone_id).first() if payment.milestone_id else None
    return page(request, 'portal/pay.html', {
        'payment': payment, 'req': req, 'milestone': milestone,
        'contractor': Contractors.objects.filter(pk=req.contractor_id).first() if req.contractor_id else None})


@portal_login_required('client', 'contractor')
def receipt(request, pid):
    payment, req = _payment_for(request, pid, 'paid')
    if payment is None:
        messages.error(request, 'Receipt not found.')
        return redirect(ROLES[request.who.role][2])
    return page(request, 'portal/receipt.html', {
        'payment': payment, 'req': req, 'method_label': PAY_METHOD_LABELS.get(payment.method or '', payment.method or '-'),
        'milestone': Milestone.objects.filter(pk=payment.milestone_id).first() if payment.milestone_id else None,
        'client': TableUser.objects.filter(pk=req.user_id).first(),
        'contractor': Contractors.objects.filter(pk=req.contractor_id).first() if req.contractor_id else None})


# --------------------------------------------------------------- contractor
@portal_login_required('contractor')
def contractor_dashboard(request):
    mine = ProjectRequirements.objects.filter(contractor_id=str(request.who.id)).order_by('-id')
    clients = _names(TableUser)
    ongoing, previous = [], []
    for r in mine:
        row = {'req': r, 'client': clients.get(str(r.user_id), '-')}
        if r.requirement_status in ACTIVE_STATUSES:
            ongoing.append(row)
        elif r.requirement_status == 'Completed':
            previous.append(row)
    return page(request, 'portal/dashboard_contractor.html', {'ongoing': ongoing, 'previous': previous})


# ------------------------------------------------- shared project page
@portal_login_required()
def project_detail(request, rid):
    req = _get_req(rid)
    who = request.who
    if req is None or not _can_access(who, req):
        messages.error(request, 'Project not found.')
        return redirect(ROLES[who.role][2])

    milestones = list(Milestone.objects.filter(requirement_id=rid).order_by('seq'))
    updates = list(PlanDailyUpdates.objects.filter(plan_id=str(rid)).order_by('-date', '-id')[:40])
    per_ms = {}
    for u in updates:
        if u.milestone_id:
            per_ms.setdefault(u.milestone_id, []).append(u)
    for m in milestones:
        m.recent = per_ms.get(m.id, [])[:3]

    payments = list(WeeklyPayments.objects.filter(plan_id=str(rid)).order_by('-id'))
    for p in payments:
        p.method_label = PAY_METHOD_LABELS.get(p.method or '', '')

    plan_url, plan_is_image = _plan_info(req)
    status = req.requirement_status
    ctx = {
        'req': req, 'status': status,
        'client': TableUser.objects.filter(pk=req.user_id).first(),
        'contractor': Contractors.objects.filter(pk=req.contractor_id).first() if req.contractor_id else None,
        'plan_url': plan_url, 'plan_is_image': plan_is_image,
        'estimate': CostEstimate.objects.filter(requirement_id=rid).order_by('-id').first(),
        'milestones': milestones, 'progress': _progress(milestones), 'updates': updates,
        'payments': payments,
        'paid_total': sum(float(p.amount) for p in payments if p.status == 'paid'),
        'due_total': sum(float(p.amount) for p in payments if p.status == 'pending'),
        'can_accept_plan': who.role == 'client' and status == 'Plan Submitted',
        'can_regenerate': who.role == 'client' and status == 'Plan Submitted',
        'can_work': who.role == 'contractor' and status == 'Plan Accepted',
        'can_generate': who.role == 'contractor' and status == 'Plan Accepted' and not milestones,
    }
    return page(request, 'portal/project.html', ctx)
