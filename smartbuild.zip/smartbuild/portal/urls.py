from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='portal_home'),
    path('login/', views.login_view, name='portal_login'),
    path('logout/', views.logout_view, name='portal_logout'),
    path('register/', views.register, name='portal_register'),

    path('client/', views.client_dashboard, name='portal_client'),
    path('client/new/', views.client_new_requirement, name='portal_new_requirement'),
    path('client/contractors/', views.client_contractors, name='portal_contractors'),
    path('client/project/<int:rid>/accept-plan/', views.client_accept_plan, name='portal_accept_plan'),
    path('client/project/<int:rid>/new-layout/', views.client_regenerate_plan, name='portal_new_layout'),

    path('pay/<int:pid>/', views.pay_page, name='portal_pay'),
    path('receipt/<int:pid>/', views.receipt, name='portal_receipt'),

    path('contractor/', views.contractor_dashboard, name='portal_contractor'),

    path('project/<int:rid>/', views.project_detail, name='portal_project'),
]
