from django import template

from smartbuild.services.estimator import format_inr

register = template.Library()


@register.filter
def inr(value):
    """20,00,000 style rupee formatting; blank for empty values."""
    if value in (None, ''):
        return '-'
    try:
        return format_inr(float(value))
    except (TypeError, ValueError):
        return value


@register.filter
def badge(status):
    """CSS class for a status label."""
    s = (status or '').lower()
    if s in ('completed', 'approved', 'paid', 'plan accepted'):
        return 'green'
    if s in ('pending', 'in progress', 'accepted', 'plan submitted'):
        return 'amber'
    return 'grey'
