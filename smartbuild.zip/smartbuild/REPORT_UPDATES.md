# Report changes for the BuildSmart web version

## Title, roles and technology
- Roles: **Admin, User (client), Contractor**. Remove Designer and Worker everywhere (use case, DFD, ER, user rights, screenshots).
- "Android and Django" becomes **web application: Python (Django), MySQL, HTML, CSS, JavaScript**. Delete the Android/JRE/JDK sections; hardware becomes "any device with Chrome or Edge". 4.1 says PHP: change to Python.

## Modules (replace the module list)
1. **User & Admin Management:** register/login for users and contractors, admin accounts and monitoring.
2. **AI Plan Designer:** generates a floor plan for every floor from bedrooms, bathrooms, floors, garage and area.
3. **Cost Estimation:** machine-learning cost range with a budget feasibility check.
4. **Project & Stage Management:** plan acceptance, contractor works, payment stages.
5. **Progress Tracking:** daily updates by typing or Malayalam voice with an English summary.
6. **Payments:** client pays each approved stage online (demo checkout) and gets a receipt; admin monitors all payments.

## 2.1.2 Proposed system (add)
The old system only listed plans and finished works. The proposed web system lets a user create a house plan and cost estimate in seconds with an AI designer, hire a contractor, follow daily progress and pay stage by stage after approving each stage.

## 2.1.1 Existing systems (add, with sources you have checked)
Procore, Buildertrend and similar tools manage projects but are costly, need an existing contractor and do not generate plans or accept regional-language voice updates. Verify each claim on the vendor's site before citing it.

## Algorithms to describe honestly
- **Plan generation:** rule-based generative design: (1) split rooms across floors, (2) build a room programme with target areas, (3) put the staircase and service rooms in a core strip that lines up between floors, (4) split the remaining area into public and private zones and pack rooms with a squarified treemap, choosing the zoning with the best room proportions, (5) draw the result as SVG. Say clearly it is not a neural network and the output is a concept sketch that an architect must finalise.
- **Cost model:** Random Forest regression, 80/20 split. If trained on synthetic data say so and quote R2 and MAE from `train_estimator`; these show the pipeline works, not real-world accuracy.

## 3.5 Table design
**tbl_cost_estimates:** id (PK), requirement_id (FK), user_id (FK), budget, predicted_cost, min_cost, max_cost, feasibility, feasibility_note, suggested_sq_ft, model_version, created_at.
**tbl_milestones:** id (PK), requirement_id (FK), seq, name, percent_of_cost, amount, status (Pending / In Progress / Completed / Approved), rejection_note, completed_at, approved_at, created_at.
**Changed:** `tbl_plan_daily_updates` + milestone_id, transcript, summary. `tbl_weekly_payments` + milestone_id, method, txn_ref, paid_at. `tbl_project_requirements`: plan_file now holds the AI-generated SVG.

## Test cases (run them; record real results only)
| Function | Test | Expected | Status |
|---|---|---|---|
| Login | Wrong password (each role) | Message on the same page, no crash | To be tested |
| Login | Admin account that is not a superuser | Refused | To be tested |
| Register | Phone not 10 digits / duplicate email | Rejected | To be tested |
| AI plan | 6 bedrooms in 600 sq ft | Refused with a reason | Passed (automated) |
| AI plan | Random valid requests (4,000+) | Rooms tile the floor, no overlap, counts correct | Passed (automated) |
| AI plan | Stairs on a 3-floor plan | Same position on every floor | Passed (automated) |
| Estimate | Budget far below minimum | Warning and suggested area | Passed (automated) |
| Project | Another user opens the project URL | "Project not found" | To be tested |
| Plan | Accept plan twice | Second time refused | To be tested |
| Stage | Complete with no update posted | Refused | To be tested |
| Stage | Approve before contractor completes | Refused | To be tested |
| Stage | Approve twice | Only one payment | To be tested |
| Pay | Pay a payment that belongs to another user | Refused | To be tested |
| Pay | Pay the same payment twice | Second refused | To be tested |
| Receipt | Open a receipt of another user | Not found | To be tested |
| Milestones | Any total | Stage amounts add up exactly | Passed (automated) |

Do not mark a row Passed until you have seen it pass.

## Future enhancement
Real payment gateway (Razorpay/PayU), chatbot, delay prediction, site-photo progress analysis, a trained plan-generation model, notifications, a mobile app on the same API.


## Additional module: Labour / Material Charges
Beyond the 5 fixed payment stages, the contractor can raise a one-off charge (a short description and an amount) for extra labour or materials. It is stored in `tbl_weekly_payments` with `category = 'labour'` and a `label` describing the charge (stage payments use `category = 'milestone'`), and is paid through the same checkout and receipt flow as a stage. Add to 3.5 Table Design: `tbl_weekly_payments` + category, label.
