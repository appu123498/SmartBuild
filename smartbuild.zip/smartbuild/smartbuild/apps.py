from django.apps import AppConfig


class SmartbuildConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'smartbuild'
    verbose_name = 'Smart Build Assistant'
