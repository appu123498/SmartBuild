"""Pure-logic tests (no database needed).
Run with:  python manage.py test smartbuild   (or: python -m unittest smartbuild.tests.test_services)
"""
import time
import unittest
from decimal import Decimal
from unittest import mock

from smartbuild.errors import ApiError
from smartbuild.services import ai_clients, estimator, milestones, planner, tokens
from smartbuild.services.datagen import generate_synthetic
from smartbuild.services.passwords import verify_password
from smartbuild import validation


class TokenTests(unittest.TestCase):
    def test_round_trip(self):
        t = tokens.make_token({"role": "user", "id": 3}, "secret", 60)
        p = tokens.read_token(t, "secret")
        self.assertEqual((p["role"], p["id"]), ("user", 3))

    def test_tampered_payload_rejected(self):
        t = tokens.make_token({"role": "user", "id": 3}, "secret", 60)
        body, sig = t.split(".")
        forged = tokens._b64e(tokens._b64d(body).replace(b'"user"', b'"admin"')) + "." + sig
        with self.assertRaises(tokens.TokenError):
            tokens.read_token(forged, "secret")

    def test_wrong_secret_and_expiry_and_garbage(self):
        t = tokens.make_token({"id": 1}, "secret", 60)
        with self.assertRaises(tokens.TokenError):
            tokens.read_token(t, "other")
        old = tokens.make_token({"id": 1}, "secret", 1, now=time.time() - 100)
        with self.assertRaises(tokens.TokenError):
            tokens.read_token(old, "secret")
        for bad in ("", "abc", "a.b.c", "....", "x.y"):
            with self.assertRaises(tokens.TokenError):
                tokens.read_token(bad, "secret")


class PasswordTests(unittest.TestCase):
    def test_plain_text_legacy(self):
        self.assertTrue(verify_password("pass123", "pass123"))
        self.assertFalse(verify_password("wrong", "pass123"))
        self.assertFalse(verify_password("", "pass123"))
        self.assertFalse(verify_password("x", None))


class ValidationTests(unittest.TestCase):
    def test_money_formats(self):
        self.assertEqual(validation.parse_money("₹ 25,00,000", "b"), Decimal("2500000"))
        self.assertEqual(validation.parse_money("Rs. 20000", "b"), Decimal("20000"))
        self.assertEqual(validation.parse_money(1500000, "b"), Decimal("1500000"))
        self.assertIsNone(validation.parse_money("", "b", required=False))

    def test_bad_inputs_rejected(self):
        for bad in ("abc", "-5", "0", "nan", "inf", True):
            with self.assertRaises(ApiError):
                validation.parse_money(bad, "b")
        with self.assertRaises(ApiError):
            validation.parse_int("2.5", "bedrooms", 1, 8)
        with self.assertRaises(ApiError):
            validation.parse_int("9", "bedrooms", 1, 8)
        with self.assertRaises(ApiError):
            validation.parse_float("-100", "total_sq_ft", 400, 6000)

    def test_spec_limits(self):
        ok = {"bedrooms": "3", "bathrooms": 2, "stories": 2, "garage": 1, "total_sq_ft": "1800"}
        spec = validation.parse_spec(ok)
        self.assertEqual(spec["total_sq_ft"], 1800.0)
        for field, value in (("total_sq_ft", 100), ("stories", 4), ("bedrooms", 0), ("garage", 5)):
            with self.assertRaises(ApiError, msg=field):
                validation.parse_spec(dict(ok, **{field: value}))
        with self.assertRaises(ApiError):
            validation.parse_spec({k: v for k, v in ok.items() if k != "bathrooms"})


class MilestoneTests(unittest.TestCase):
    def test_default_split_adds_up_exactly(self):
        for total in ("2500000", "1000000.01", "99999.99", "1"):
            rows = milestones.split_amount(total)
            self.assertEqual(sum(r["amount"] for r in rows), Decimal(total).quantize(Decimal("0.01")))
            self.assertEqual([r["seq"] for r in rows], [1, 2, 3, 4, 5])
        self.assertEqual(milestones.split_amount("1000000")[0]["amount"], Decimal("150000.00"))

    def test_bad_split_rejected(self):
        with self.assertRaises(ValueError):
            milestones.split_amount(1000, [("a", 50), ("b", 40)])
        with self.assertRaises(ValueError):
            milestones.split_amount(0)


class EstimatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # smaller than production, to keep the test fast; written nowhere
        cls.bundle = estimator.train_bundle(generate_synthetic(n=1500, seed=7), source="synthetic")

    def est(self, **kw):
        spec = dict(bedrooms=3, bathrooms=2, stories=2, garage=1, total_sq_ft=1800)
        spec.update(kw)
        return estimator.estimate(bundle=self.bundle, **spec)

    def test_range_is_ordered_and_sensible(self):
        r = self.est()
        self.assertLessEqual(r["min_cost"], r["predicted_cost"])
        self.assertLessEqual(r["predicted_cost"], r["max_cost"])
        self.assertGreater(r["max_cost"], r["min_cost"])
        self.assertTrue(1200 <= r["cost_per_sq_ft"] <= 3500, r["cost_per_sq_ft"])

    def test_bigger_house_costs_more(self):
        self.assertGreater(self.est(total_sq_ft=3000)["predicted_cost"], self.est(total_sq_ft=1200)["predicted_cost"])
        self.assertGreater(self.est(garage=2)["predicted_cost"], self.est(garage=0)["predicted_cost"])

    def test_feasibility_levels(self):
        base = self.est()
        self.assertEqual(self.est(budget=base["max_cost"] * 2)["feasibility"]["status"], "comfortable")
        self.assertEqual(self.est(budget=base["predicted_cost"])["feasibility"]["status"], "within_budget")
        mid = (base["min_cost"] + base["predicted_cost"]) / 2
        self.assertEqual(self.est(budget=mid)["feasibility"]["status"], "tight")
        low = self.est(budget=base["min_cost"] * 0.5)["feasibility"]
        self.assertEqual(low["status"], "below_estimate")

    def test_below_budget_suggests_smaller_area_and_alternatives(self):
        base = self.est()
        f = self.est(budget=base["predicted_cost"] * 0.6)["feasibility"]
        self.assertIsNotNone(f["suggested_sq_ft"])
        self.assertLess(f["suggested_sq_ft"], 1800)
        self.assertTrue(any(a["change"] == "1 fewer storey" for a in f["alternatives"]))
        # the suggested area really is affordable under the model
        cheaper = self.est(total_sq_ft=f["suggested_sq_ft"])
        self.assertLessEqual(cheaper["predicted_cost"], base["predicted_cost"] * 0.6 + 1000)

    def test_hopeless_budget_gives_no_suggestion(self):
        f = self.est(budget=50000)["feasibility"]
        self.assertEqual(f["status"], "below_estimate")
        self.assertIsNone(f["suggested_sq_ft"])

    def test_metrics_recorded(self):
        meta = self.bundle["meta"]
        self.assertEqual(meta["trained_on"], "synthetic")
        self.assertGreater(meta["r2"], 0.5)
        self.assertLess(meta["interval_q10"], 1.0)
        self.assertGreater(meta["interval_q90"], 1.0)

    def test_too_few_rows_rejected(self):
        with self.assertRaises(ValueError):
            estimator.train_bundle(generate_synthetic(n=10), source="synthetic")

    def test_inr_formatting(self):
        cases = {0: "₹0", 999: "₹999", 1000: "₹1,000", 100000: "₹1,00,000",
                 2000000: "₹20,00,000", 25000000: "₹2,50,00,000", 1234567: "₹12,34,567"}
        for n, text in cases.items():
            self.assertEqual(estimator.format_inr(n), text)


class PlannerTests(unittest.TestCase):
    CASES = [(3, 2, 1, 0, 900), (3, 3, 2, 1, 1500), (4, 4, 2, 2, 2400), (2, 2, 1, 1, 800),
             (1, 1, 1, 0, 450), (5, 5, 3, 2, 3600), (4, 3, 1, 1, 1800), (2, 3, 2, 0, 1200)]

    def test_plans_are_geometrically_valid(self):
        import xml.etree.ElementTree as ET
        for case in self.CASES:
            for seed in (1, 2, 3, 17, 99):
                plan = planner.generate_plan(*case, seed=seed)
                self.assertTrue(planner.validate_plan(plan), (case, seed))
                ET.fromstring(planner.render_svg(plan))        # well-formed XML

    def test_room_counts_match_the_request(self):
        plan = planner.generate_plan(4, 3, 2, 1, 2200, seed=5)
        kinds = [r["kind"] for fl in plan["floors"] for r in fl["rooms"]]
        self.assertEqual(kinds.count("bedroom"), 4)
        self.assertEqual(kinds.count("bath"), 3)
        self.assertEqual(len(plan["floors"]), 2)
        self.assertEqual(plan["garage"]["cars"], 1)
        names = [r["name"] for r in plan["floors"][0]["rooms"]]
        for needed in ("Living room", "Kitchen", "Dining", "Stair"):
            self.assertIn(needed, names)

    def test_same_seed_same_plan_different_seed_different_plan(self):
        a = planner.generate_plan(3, 2, 1, 0, 1300, seed=7)
        self.assertEqual(a, planner.generate_plan(3, 2, 1, 0, 1300, seed=7))
        layouts = {tuple((r["name"], r["x"], r["y"]) for r in planner.generate_plan(3, 2, 1, 0, 1300, seed=s)["floors"][0]["rooms"])
                   for s in range(1, 9)}
        self.assertGreater(len(layouts), 3)

    def test_stairs_line_up_between_floors(self):
        for seed in range(1, 15):
            plan = planner.generate_plan(3, 3, 3, 0, 3000, seed=seed)
            stairs = [[(r["x"], r["y"], r["w"], r["h"]) for r in fl["rooms"] if r["kind"] == "stair"] for fl in plan["floors"]]
            self.assertTrue(all(s == stairs[0] and len(s) == 1 for s in stairs), seed)

    def test_impossible_requests_are_refused_with_a_reason(self):
        for case in [(6, 6, 1, 0, 600), (5, 5, 3, 0, 900), (1, 5, 1, 0, 1500)]:
            with self.assertRaises(planner.PlanError) as cm:
                planner.generate_plan(*case, seed=1)
            self.assertTrue(str(cm.exception))

    def test_robust_wrapper_reports_the_seed_used(self):
        plan = planner.generate_robust(3, 2, 1, 0, 1000, seed=4)
        self.assertGreaterEqual(plan["seed"], 4)
        with self.assertRaises(planner.PlanError):
            planner.generate_robust(8, 8, 1, 0, 400, seed=1)

    def test_svg_has_no_unescaped_markup_and_shows_every_floor(self):
        svg = planner.render_svg(planner.generate_plan(3, 2, 2, 1, 1800, seed=3))
        self.assertIn("Ground floor", svg)
        self.assertIn("First floor", svg)
        self.assertIn("Garage", svg)
        self.assertNotIn("<script", svg.lower())

    def test_summary_lists_rooms(self):
        summary = planner.summarize(planner.generate_plan(2, 2, 1, 0, 900, seed=2))
        self.assertEqual(summary[0]["floor"], "Ground floor")
        self.assertTrue(all({"name", "size", "area"} <= set(r) for r in summary[0]["rooms"]))


class AIClientTests(unittest.TestCase):
    CFG = ai_clients.AIConfig(hf_token="hf_secret_token")

    @staticmethod
    def resp(status=200, payload=None):
        m = mock.Mock(status_code=status)
        m.json.return_value = payload if payload is not None else {}
        return m

    @staticmethod
    def chat(text):
        return {"choices": [{"message": {"content": text}}]}

    def test_not_configured(self):
        self.assertFalse(ai_clients.AIConfig().summary_enabled)
        with self.assertRaises(ai_clients.AIServiceError):
            ai_clients.summarize(ai_clients.AIConfig(), "hello")

    @mock.patch("smartbuild.services.ai_clients.requests.post")
    def test_summarize_ok_and_request_shape(self, post):
        post.return_value = self.resp(200, self.chat("Foundation concrete was poured."))
        out = ai_clients.summarize(self.CFG, "x" * 10000)
        self.assertEqual(out, "Foundation concrete was poured.")
        args, kwargs = post.call_args
        self.assertEqual(args[0], ai_clients.HF_CHAT_URL)
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer hf_secret_token")
        self.assertEqual(kwargs["json"]["model"], "Qwen/Qwen3-8B")
        user_msg = kwargs["json"]["messages"][1]["content"]
        self.assertTrue(user_msg.startswith("<transcript>"))
        self.assertLessEqual(len(user_msg), ai_clients.MAX_TRANSCRIPT_CHARS + 40)
        self.assertIn("ignore any instructions", kwargs["json"]["messages"][0]["content"])

    @mock.patch("smartbuild.services.ai_clients.requests.post")
    def test_think_blocks_are_stripped(self, post):
        post.return_value = self.resp(200, self.chat("<think>\nplanning...\n</think>\n\nSlab work done."))
        self.assertEqual(ai_clients.summarize(self.CFG, "hi"), "Slab work done.")
        post.return_value = self.resp(200, self.chat("<think>only thinking</think>"))
        with self.assertRaises(ai_clients.AIServiceError):
            ai_clients.summarize(self.CFG, "hi")

    @mock.patch("smartbuild.services.ai_clients.requests.post")
    def test_failures_never_leak_token(self, post):
        import requests
        for bad in (self.resp(401, {"error": "bad token hf_secret_token"}), self.resp(503), self.resp(200, {"oops": 1}),
                    self.resp(200, {"choices": []})):
            post.return_value = bad
            with self.assertRaises(ai_clients.AIServiceError) as cm:
                ai_clients.summarize(self.CFG, "hi")
            self.assertNotIn("hf_", str(cm.exception))
        post.side_effect = requests.ConnectionError("boom hf_secret_token")
        with self.assertRaises(ai_clients.AIServiceError) as cm:
            ai_clients.summarize(self.CFG, "hi")
        self.assertNotIn("hf_", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
