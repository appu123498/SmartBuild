class ApiError(Exception):
    """Raised anywhere in the API layer; converted to a JSON error response."""

    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message
