from django.db import OperationalError, ProgrammingError
from django.shortcuts import redirect, render

from login.models import WeeklyPayments
from .models import CostEstimate, Milestone

DB_ERRORS = (OperationalError, ProgrammingError)


def _safe(label, query):
    """Run a queryset; if a table/column from a schema update is missing, show
    that section as unavailable instead of crashing the whole admin page."""
    try:
        return list(query), None
    except DB_ERRORS as exc:
        return [], '%s is unavailable: %s. Run the sql/smartbuild_schema*.sql files in phpMyAdmin.' % (label, exc)


def milestones_page(request):
    """Admin overview of milestones, cost estimates and payments (admin login required)."""
    if not request.user.is_authenticated or not request.user.is_superuser:
        return redirect('/portal/login/?role=admin')
    milestones, m_err = _safe('Milestones', Milestone.objects.all().order_by('requirement_id', 'seq'))
    estimates, e_err = _safe('Cost estimates', CostEstimate.objects.all().order_by('-id')[:50])
    payments, p_err = _safe('Payments', WeeklyPayments.objects.all().order_by('-id')[:100])
    context = {
        'milestones': milestones, 'estimates': estimates, 'payments': payments,
        'errors': [e for e in (m_err, e_err, p_err) if e],
    }
    return render(request, 'smartbuild/milestones.html', context)
