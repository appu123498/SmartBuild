from django.urls import path

from . import views

urlpatterns = [
    path('health/', views.health, name='sb_health'),
    path('auth/login/', views.auth_login, name='sb_login'),

    path('estimate/', views.estimate_cost, name='sb_estimate'),
    path('estimate/<int:rid>/', views.estimate_saved, name='sb_estimate_saved'),

    path('my/plans/', views.my_plans, name='sb_my_plans'),
    path('plan/generate/', views.plan_generate, name='sb_plan_generate'),

    path('requirements/<int:rid>/milestones/', views.milestones_list, name='sb_milestones'),
    path('requirements/<int:rid>/milestones/generate/', views.milestones_generate, name='sb_milestones_generate'),
    path('milestones/<int:mid>/complete/', views.milestone_complete, name='sb_milestone_complete'),
    path('milestones/<int:mid>/approve/', views.milestone_approve, name='sb_milestone_approve'),
    path('milestones/<int:mid>/reject/', views.milestone_reject, name='sb_milestone_reject'),

    path('requirements/<int:rid>/charges/', views.charge_create, name='sb_charge_create'),
    path('payments/<int:pid>/pay/', views.payment_pay, name='sb_payment_pay'),

    path('updates/', views.post_update, name='sb_post_update'),
    path('requirements/<int:rid>/updates/', views.updates_list, name='sb_updates'),
]
