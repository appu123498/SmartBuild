"""Tiny JSON-API plumbing: auth, JSON bodies, uniform error responses.

No Django REST Framework needed. Android sends:
    Authorization: Bearer <token from POST /api/auth/login/>
"""
import functools
import json
from collections import namedtuple

from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .errors import ApiError
from .services.tokens import TokenError, read_token

ApiUser = namedtuple('ApiUser', 'role id name')


def config():
    return settings.SMARTBUILD


def _authenticate(request, roles):
    header = request.META.get('HTTP_AUTHORIZATION', '')
    if not header.startswith('Bearer '):
        raise ApiError(401, 'Missing or invalid Authorization header')
    try:
        payload = read_token(header[7:].strip(), settings.SECRET_KEY)
    except TokenError as exc:
        raise ApiError(401, 'Invalid or expired token: %s' % exc)
    user = ApiUser(payload.get('role'), payload.get('id'), payload.get('name') or '')
    if user.role not in roles:
        raise ApiError(403, 'This action is not available for the %s role' % user.role)
    return user


def api(methods, roles=None):
    """roles=None -> public endpoint; otherwise a list of allowed roles."""
    def decorator(view):
        @functools.wraps(view)
        def wrapper(request, *args, **kwargs):
            try:
                if request.method not in methods:
                    raise ApiError(405, 'Method not allowed')
                if roles is not None:
                    request.api_user = _authenticate(request, roles)
                result = view(request, *args, **kwargs)
                if isinstance(result, HttpResponse):
                    return result
                status = 200
                if isinstance(result, tuple):
                    result, status = result
                return JsonResponse(result, status=status, json_dumps_params={'ensure_ascii': False})
            except ApiError as exc:
                return JsonResponse({'error': exc.message}, status=exc.status)
        return csrf_exempt(wrapper)
    return decorator


def json_body(request):
    """JSON body for application/json, otherwise form fields (multipart/urlencoded)."""
    if request.META.get('CONTENT_TYPE', '').startswith('application/json'):
        try:
            data = json.loads(request.body.decode('utf-8') or '{}')
        except ValueError:
            raise ApiError(400, 'Invalid JSON body')
        if not isinstance(data, dict):
            raise ApiError(400, 'JSON body must be an object')
        return data
    return request.POST.dict()
