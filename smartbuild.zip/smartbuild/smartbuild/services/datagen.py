"""Synthetic training data for the cost estimator.

IMPORTANT: every number below is a PLACEHOLDER ASSUMPTION (INR, roughly
Kerala residential construction), not measured data. A model trained on this
learns these rules, so its accuracy figures only show the pipeline works.
For a real accuracy claim, train on real past-project costs:
    python manage.py train_estimator --csv my_projects.csv
"""
from __future__ import annotations

import math
import random

ASSUMPTIONS = {
    "rate_per_sq_ft_range": (1500, 2300),     # finish quality, NOT a model input
    "extra_cost_per_extra_storey": 0.04,      # +4% per sq ft for each storey above 1
    "bathroom_extra_range": (60000, 100000),  # fixtures, plumbing, tiling
    "garage_extra_range": (150000, 300000),   # per garage / car porch unit
    "bedroom_extra": 20000,                   # wardrobes, extra electrical
}


def generate_synthetic(n: int = 3000, seed: int = 42):
    rng = random.Random(seed)
    a = ASSUMPTIONS
    rows = []
    for _ in range(n):
        sq_ft = min(6000, max(400, rng.lognormvariate(math.log(1500), 0.45)))
        sq_ft = int(round(sq_ft / 10.0) * 10)
        max_stories = 1 if sq_ft < 700 else (2 if sq_ft < 1200 else 3)
        stories = rng.choices([1, 2, 3][:max_stories], [0.55, 0.35, 0.10][:max_stories])[0]
        bedrooms = int(min(8, max(1, round(sq_ft / 450.0 + rng.gauss(0, 0.7)))))
        bathrooms = int(min(8, max(1, round(bedrooms * rng.uniform(0.6, 1.2)))))
        garage = rng.choices([0, 1, 2, 3], [0.35, 0.50, 0.14, 0.01])[0]

        rate = rng.uniform(*a["rate_per_sq_ft_range"])
        cost = sq_ft * rate * (1 + a["extra_cost_per_extra_storey"] * (stories - 1))
        cost += bathrooms * rng.uniform(*a["bathroom_extra_range"])
        cost += garage * rng.uniform(*a["garage_extra_range"])
        cost += bedrooms * a["bedroom_extra"]
        cost *= rng.lognormvariate(0, 0.04)

        rows.append({
            "bedrooms": bedrooms, "bathrooms": bathrooms, "stories": stories,
            "garage": garage, "total_sq_ft": sq_ft, "cost": round(cost, -3),
        })
    return rows
