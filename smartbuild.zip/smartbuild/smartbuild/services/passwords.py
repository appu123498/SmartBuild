"""Password check that works with BOTH storage styles.

Your existing tables (tbl_users, tbl_contractors, ...) store plain text.
If you later switch to Django hashes (make_password), this keeps working
without another code change.
"""
from __future__ import annotations

import hmac

try:  # Django is present in the real project
    from django.contrib.auth.hashers import check_password, identify_hasher
except ImportError:  # pragma: no cover - only when run outside Django
    check_password = identify_hasher = None


def verify_password(raw: str, stored: str | None) -> bool:
    if not raw or not stored:
        return False
    if identify_hasher is not None:
        try:
            identify_hasher(stored)
        except ValueError:
            pass  # not a Django hash -> legacy plain text, handled below
        else:
            return check_password(raw, stored)
    return hmac.compare_digest(raw.encode("utf-8"), stored.encode("utf-8"))
