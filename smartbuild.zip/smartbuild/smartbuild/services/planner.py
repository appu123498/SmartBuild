"""AI-assisted floor plan generator.

HONEST DESCRIPTION: this is a rule-based generative layout algorithm (room
programme -> zoning -> squarified treemap packing), not a trained neural
network. It produces concept sketches for discussion. They are NOT structural,
legal or approved drawings: a licensed architect/engineer must prepare and
approve the real drawings before construction.

Units are feet. Coordinates: x to the right, y downward; the FRONT (road side)
of every floor is the bottom edge.
"""
from __future__ import annotations

import math
import random
from xml.sax.saxutils import escape


class PlanError(ValueError):
    """A user-presentable reason why no plan could be made."""


FLOOR_NAMES = ["Ground floor", "First floor", "Second floor"]
MIN_DIM = 3.5          # no room may be thinner than this (ft)
RAW = {                # starting target areas (sq ft); scaled to fill the floor
    "bedroom": 110, "master": 140, "attached_bath": 35, "common_bath": 32,
    "living": 170, "dining": 90, "kitchen": 100, "utility": 30, "lounge": 120,
    "balcony": 50, "family": 120, "study": 90, "store": 28,
}
MIN_BEDROOM, MIN_LIVING, MIN_KITCHEN, MIN_ANY = 75, 85, 45, 24
KIND_COLORS = {
    "living": "#fde68a", "dining": "#fed7aa", "kitchen": "#bbf7d0", "bedroom": "#bfdbfe",
    "bath": "#e9d5ff", "stair": "#e5e7eb", "utility": "#fecaca", "lounge": "#fde68a",
    "balcony": "#d1fae5", "family": "#fef3c7", "study": "#ddd6fe", "store": "#f3f4f6",
    "garage": "#d1d5db",
}


# ----------------------------------------------------------------- allocation
def _spread(total, floors):
    base, extra = divmod(total, floors)
    counts = [base] * floors
    for i in range(extra):          # leftovers go to the upper floors first
        counts[floors - 1 - i] += 1
    return counts


def _allocate_baths(total, bed_counts):
    floors = len(bed_counts)
    tc = [0] * floors
    remaining = total
    if remaining:
        tc[0], remaining = 1, remaining - 1       # a common bath on the ground floor
    order = list(range(1, floors)) + [0]
    while remaining:
        progressed = False
        for f in order:
            cap = bed_counts[f] + (1 if f == 0 else 0)
            if tc[f] < cap and remaining:
                tc[f] += 1
                remaining -= 1
                progressed = True
        if not progressed:
            tc[0] += 1
            remaining -= 1
    result = []
    for f in range(floors):
        attached = min(bed_counts[f], tc[f] - (1 if f == 0 and tc[f] else 0))
        result.append((attached, tc[f] - attached))   # (attached baths, common baths)
    return result


# -------------------------------------------------------------- layout maths
def _squarify(cells, x, y, w, h, rng):
    """cells: [(key, area)]. Returns {key: (x, y, w, h)} exactly tiling the rectangle."""
    total = float(sum(a for _, a in cells))
    jitter = [(k, a * rng.uniform(0.94, 1.06)) for k, a in cells]
    s = (w * h) / sum(a for _, a in jitter)
    items = sorted(((k, a * s) for k, a in jitter), key=lambda t: -t[1])
    out = {}

    def worst(areas, side):
        tot = sum(areas)
        return max(max(side * side * r / (tot * tot), tot * tot / (side * side * r)) for r in areas)

    while items:
        side = min(w, h)
        row, i = [items[0]], 1
        while i < len(items) and worst([a for _, a in row + [items[i]]], side) <= worst([a for _, a in row], side):
            row.append(items[i])
            i += 1
        items = items[i:]
        tot = sum(a for _, a in row)
        if w >= h:                       # a column on the left
            cw = tot / h
            yy = y
            for k, a in row:
                rh = a / cw
                out[k] = (x, yy, cw, rh)
                yy += rh
            x, w = x + cw, w - cw
        else:                            # a row along the top
            rh = tot / w
            xx = x
            for k, a in row:
                cw = a / rh
                out[k] = (xx, y, cw, rh)
                xx += cw
            y, h = y + rh, h - rh
    return out


def _strip(cells, x, y, w, h):
    """Fallback: one row/column along the longer side, sized by area."""
    total = float(sum(a for _, a in cells))
    out, pos = {}, 0.0
    for k, a in cells:
        share = a / total
        if w >= h:
            out[k] = (x + pos * w, y, share * w, h)
        else:
            out[k] = (x, y + pos * h, w, share * h)
        pos += share
    return out


def _pack(cells, x, y, w, h, rng):
    if len(cells) == 1:
        return {cells[0][0]: (x, y, w, h)}
    for _ in range(25):                  # jittered attempts, then a plain strip layout
        out = _squarify(cells, x, y, w, h, rng)
        if all(min(r[2], r[3]) >= MIN_DIM for r in out.values()):
            return out
    out = _strip(cells, x, y, w, h)
    if all(min(r[2], r[3]) >= MIN_DIM for r in out.values()):
        return out
    raise PlanError("These rooms cannot be fitted neatly into %d sq ft. Try a slightly larger area "
                    "or fewer rooms." % int(w * h))


def _inset_bath(cell_w, cell_h, area, corner):
    bw = max(4.5, min(cell_w * 0.55, math.sqrt(area * 1.2)))
    bh = area / bw
    if bh > cell_h * 0.6:
        bh = cell_h * 0.6
        bw = min(cell_w * 0.6, area / bh)
    ox = 0.0 if corner[0] == "l" else cell_w - bw
    oy = 0.0 if corner[1] == "t" else cell_h - bh
    return ox, oy, bw, bh



def _aspect(rects):
    return max(max(r[2] / r[3], r[3] / r[2]) for r in rects.values())


def _best_zoning(pub_cells, priv_cells, x0, w0, d0, rng):
    """Try several ways to split the area into a public and a private zone and keep
    the one whose rooms are best proportioned (lowest worst aspect ratio)."""
    if not (pub_cells and priv_cells):
        return _pack(pub_cells or priv_cells, x0, 0.0, w0, d0, rng)
    pub_area = sum(a for _, a in pub_cells)
    priv_area = sum(a for _, a in priv_cells)
    candidates = []
    ph = pub_area / w0                                    # public band at the front (bottom)
    if 0 < ph < d0:
        candidates.append([(pub_cells, x0, d0 - ph, w0, ph), (priv_cells, x0, 0.0, w0, d0 - ph)])
    pw = pub_area / d0                                    # side-by-side, public left or right
    if 0 < pw < w0:
        candidates.append([(pub_cells, x0, 0.0, pw, d0), (priv_cells, x0 + pw, 0.0, w0 - pw, d0)])
        candidates.append([(pub_cells, x0 + w0 - pw, 0.0, pw, d0), (priv_cells, x0, 0.0, w0 - pw, d0)])
    best, best_score = None, None
    for zones in candidates:
        sub = random.Random(rng.random())
        try:
            placed = {}
            for cells, zx, zy, zw, zh in zones:
                placed.update(_pack(cells, zx, zy, zw, zh, sub))
        except PlanError:
            continue
        score = _aspect(placed)
        if best is None or score < best_score - 1e-9:
            best, best_score = placed, score
    if best is None:
        raise PlanError("These rooms cannot be fitted neatly. Try a slightly larger area or fewer rooms.")
    return best


# ------------------------------------------------------------------ generator
def generate_plan(bedrooms, bathrooms, stories, garage, total_sq_ft, seed=1):
    bedrooms, bathrooms = int(bedrooms), int(bathrooms)
    stories, garage = int(stories), int(garage)
    total = float(total_sq_ft)
    seed = int(seed)
    rng = random.Random(seed)

    if bathrooms > bedrooms + 2:
        raise PlanError("%d bathrooms is too many for %d bedroom(s). Use at most %d." % (bathrooms, bedrooms, bedrooms + 2))
    per_floor = total / stories
    aspect = rng.uniform(1.15, 1.6)
    W = round(math.sqrt(per_floor * aspect) * 2) / 2
    D = round(per_floor / W * 2) / 2
    floor_area = W * D

    bed_counts = _spread(bedrooms, stories)
    bath_plan = _allocate_baths(bathrooms, bed_counts)
    core_left = rng.random() < 0.5      # same side on every floor so stairs line up
    has_core = stories > 1
    cw = (7.5 if per_floor < 1200 else 8.5) if has_core else 0.0

    floors, bed_no = [], 0
    for f in range(stories):
        beds, (attached, common) = bed_counts[f], bath_plan[f]
        ground = f == 0
        core_rooms, public, private = [], [], []

        # --- rooms that live in the core strip (multi-storey) or in the public zone
        service = [("Common bath", "bath", RAW["common_bath"])] * common
        if ground and per_floor >= 900:
            service.append(("Utility", "utility", RAW["utility"]))
        if has_core:
            core_rooms = service[:2]
            service = service[2:]
            if not core_rooms:
                core_rooms = [("Store", "store", RAW["store"])]
        public += [(n, k, a) for n, k, a in service]

        if ground:
            public += [("Living room", "living", RAW["living"]), ("Dining", "dining", RAW["dining"]),
                       ("Kitchen", "kitchen", RAW["kitchen"])]
        else:
            public.append(("Family lounge", "lounge", RAW["lounge"]))
            if per_floor >= 700:
                public.append(("Balcony", "balcony", RAW["balcony"]))
        if not ground and beds == 0:
            private.append(("Study", "study", RAW["study"], None))

        for _ in range(beds):
            bed_no += 1
            master = bed_no == 1
            bath = ("Attached bath", RAW["attached_bath"]) if len(
                [c for c in private if c[1] == "bedroom" and c[3]]) < attached else None
            private.append(("Master bedroom" if master else "Bedroom %d" % bed_no, "bedroom",
                            RAW["master"] if master else RAW["bedroom"], bath))

        rest_w = W - cw
        rest_area = rest_w * D

        def raw_total():
            return sum(a for _, _, a in public) + sum(c[2] + (c[3][1] if c[3] else 0) for c in private)

        extras = [("Family room", "family", RAW["family"]), ("Study", "study", RAW["study"])]
        while rest_area / raw_total() > 1.7 and extras and per_floor >= 1000:
            public.append(extras.pop(0))
        k = rest_area / raw_total()

        # --- sanity: refuse plans whose rooms would be unusably small
        too_small = PlanError(
            "%d sq ft is too small for %d bedroom(s) and %d bathroom(s) on %d floor(s). Increase the area "
            "or reduce the rooms." % (int(total), bedrooms, bathrooms, stories))
        for name, kind, a, bath in private:
            if (kind == "bedroom" and a * k < MIN_BEDROOM) or (a * k < MIN_ANY):
                raise too_small
        for name, kind, a in public:
            floor_min = {"living": MIN_LIVING, "kitchen": MIN_KITCHEN}.get(kind, MIN_ANY)
            if a * k < floor_min:
                raise too_small
        for name, kind, a in core_rooms:
            if D < 9.0 + 4.0 * len(core_rooms) + 1.0:
                raise too_small

        rooms = []

        def add(name, kind, x, y, w, h, parent=None):
            rooms.append({"id": "f%dr%d" % (f, len(rooms)), "name": name, "kind": kind,
                          "x": x, "y": y, "w": w, "h": h, "parent": parent})
            return rooms[-1]["id"]

        # --- core strip: stair on top (same place on every floor), services below
        core_x = 0.0 if core_left else rest_w
        rest_x = cw if core_left else 0.0
        if has_core:
            stair_h = round(max(9.0, 70.0 / cw), 1)
            add("Stair", "stair", core_x, 0.0, cw, stair_h)
            raw_sum = float(sum(a for _, _, a in core_rooms))
            yy, avail = stair_h, D - stair_h
            for name, kind, a in core_rooms:
                hh = avail * a / raw_sum
                add(name, kind, core_x, yy, cw, hh)
                yy += hh

        # --- split the rest into a public and a private zone
        pub_cells = [("pub%d" % i, a * k) for i, (_, _, a) in enumerate(public)]
        priv_cells = [("prv%d" % i, (c[2] + (c[3][1] if c[3] else 0)) * k) for i, c in enumerate(private)]
        pub_area, priv_area = sum(a for _, a in pub_cells), sum(a for _, a in priv_cells)
        placed = _best_zoning(pub_cells, priv_cells, rest_x, rest_w, D, rng)

        for i, (name, kind, a) in enumerate(public):
            x, y, w, h = placed["pub%d" % i]
            add(name, kind, x, y, w, h)
        for i, (name, kind, a, bath) in enumerate(private):
            x, y, w, h = placed["prv%d" % i]
            pid = add(name, kind, x, y, w, h)
            if bath:
                ba = min(55.0, max(28.0, bath[1] * k))
                ox, oy, bw, bh = _inset_bath(w, h, ba, ("r" if rng.random() < 0.5 else "l",
                                                         "t" if rng.random() < 0.5 else "b"))
                add(bath[0], "bath", x + ox, y + oy, bw, bh, parent=pid)

        floors.append({"index": f, "name": FLOOR_NAMES[f], "rooms": rooms})

    for fl in floors:
        for r in fl["rooms"]:
            for key in ("x", "y", "w", "h"):
                r[key] = round(r[key], 2)
            r["area"] = int(round(r["w"] * r["h"]))
    return {
        "seed": seed,
        "specs": {"bedrooms": bedrooms, "bathrooms": bathrooms, "stories": stories,
                  "garage": garage, "total_sq_ft": total},
        "plot": {"width": W, "depth": D, "floor_area": round(floor_area, 1)},
        "garage": ({"cars": garage, "w": 10.5 * garage + 1.0, "d": 18.0} if garage else None),
        "floors": floors,
    }


# ------------------------------------------------------------------ checking
def validate_plan(plan, tol=0.6):
    """Raise AssertionError if the geometry is inconsistent (used by the tests)."""
    W, D = plan["plot"]["width"], plan["plot"]["depth"]
    specs = plan["specs"]
    assert len(plan["floors"]) == specs["stories"]
    beds = baths = 0
    for fl in plan["floors"]:
        top = [r for r in fl["rooms"] if r["parent"] is None]
        by_id = {r["id"]: r for r in fl["rooms"]}
        area = 0.0
        for r in fl["rooms"]:
            assert r["w"] > 0 and r["h"] > 0, r
            if r["parent"] is None:
                assert min(r["w"], r["h"]) >= MIN_DIM - 0.01, ("room too thin", r)
                assert -tol <= r["x"] and r["x"] + r["w"] <= W + tol, ("outside width", r)
                assert -tol <= r["y"] and r["y"] + r["h"] <= D + tol, ("outside depth", r)
                area += r["w"] * r["h"]
            else:
                p = by_id[r["parent"]]
                assert r["x"] >= p["x"] - 0.05 and r["y"] >= p["y"] - 0.05, ("inset outside", r)
                assert r["x"] + r["w"] <= p["x"] + p["w"] + 0.05 and r["y"] + r["h"] <= p["y"] + p["h"] + 0.05, ("inset outside", r)
            beds += r["kind"] == "bedroom"
            baths += r["kind"] == "bath"
        assert abs(area - W * D) <= 2.0, ("rooms do not tile the floor", area, W * D)
        for i, a in enumerate(top):                    # no overlaps
            for b in top[i + 1:]:
                ox = min(a["x"] + a["w"], b["x"] + b["w"]) - max(a["x"], b["x"])
                oy = min(a["y"] + a["h"], b["y"] + b["h"]) - max(a["y"], b["y"])
                assert not (ox > 0.05 and oy > 0.05), ("overlap", a, b)
    assert beds == specs["bedrooms"], (beds, specs)
    assert baths == specs["bathrooms"], (baths, specs)
    stairs = [[(r["x"], r["y"], r["w"], r["h"]) for r in fl["rooms"] if r["kind"] == "stair"] for fl in plan["floors"]]
    if specs["stories"] > 1:
        assert all(s == stairs[0] and len(s) == 1 for s in stairs), ("stairs not aligned", stairs)
    return True


# ----------------------------------------------------------------- rendering
def _fmt(n):
    return "%d'" % int(round(n))


def render_svg(plan):
    """Return a self-contained SVG string for every floor (safe: built only from
    validated numbers and the fixed room-name vocabulary above)."""
    W, D = plan["plot"]["width"], plan["plot"]["depth"]
    g = plan["garage"]
    gw = g["w"] if g else 0.0
    total_w = W + gw + (4 if g else 0)
    S = max(6.0, min(11.0, 720.0 / total_w))            # pixels per foot
    pad_x, pad_top, gap, title_h = 46, 14, 54, 30
    ox0 = pad_x + (gw + 4) * S if g else pad_x
    floor_h = D * S + title_h + 34
    width = int(ox0 + W * S + pad_x)
    height = int(pad_top + len(plan["floors"]) * (floor_h + gap) - gap + 22)

    o = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="100%%" role="img" '
         'font-family="Segoe UI, Roboto, Arial, sans-serif">' % (width, height),
         "<title>AI concept floor plan, %d bedroom, %d floor(s), %d sq ft</title>" % (
             plan["specs"]["bedrooms"], plan["specs"]["stories"], plan["specs"]["total_sq_ft"]),
         '<defs><pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
         '<line x1="0" y1="0" x2="0" y2="6" stroke="#9ca3af" stroke-width="1.4"/></pattern></defs>',
         '<rect width="%d" height="%d" fill="#ffffff"/>' % (width, height)]

    for idx, fl in enumerate(plan["floors"]):
        top = pad_top + idx * (floor_h + gap)
        oy = top + title_h
        o.append('<text x="%d" y="%d" font-size="15" font-weight="700" fill="#111827">%s</text>' % (
            pad_x, top + 18, escape(fl["name"])))
        if g and idx == 0:
            gx, gy = pad_x, oy + (D - g["d"]) * S
            o.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" stroke="#374151" stroke-width="2"/>' % (
                gx, gy, g["w"] * S, g["d"] * S, KIND_COLORS["garage"]))
            o.append('<text x="%.1f" y="%.1f" font-size="11" text-anchor="middle" fill="#111827">Garage (%d car%s)</text>' % (
                gx + g["w"] * S / 2, gy + g["d"] * S / 2, g["cars"], "s" if g["cars"] > 1 else ""))
        for r in sorted(fl["rooms"], key=lambda q: q["parent"] is not None):
            x, y, w, h = ox0 + r["x"] * S, oy + r["y"] * S, r["w"] * S, r["h"] * S
            fill = KIND_COLORS.get(r["kind"], "#f3f4f6")
            sw = 1.4 if r["parent"] else 2.2
            o.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" stroke="#1f2937" stroke-width="%s"/>' % (
                x, y, w, h, fill, sw))
            if r["kind"] == "stair":
                o.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="url(#hatch)" stroke="none"/>' % (x, y, w, h))
            small = min(r["w"], r["h"])
            fs = max(7.0, min(12.5, small * S / 5.4))
            fs = max(5.5, min(fs, (w - 4) / (max(len(r['name']), 4) * 0.56)))   # keep the label inside the room
            label_y = y + h / 2 + (-2 if small * S > 46 else 3)
            if r["parent"]:
                label_y = y + h / 2 + 3
            o.append('<text x="%.1f" y="%.1f" font-size="%.1f" font-weight="600" text-anchor="middle" fill="#111827">%s</text>' % (
                x + w / 2, label_y, fs, escape(r["name"])))
            if small * S > 46 and not r["parent"] and r["kind"] != "stair":
                o.append('<text x="%.1f" y="%.1f" font-size="%.1f" text-anchor="middle" fill="#4b5563">%s x %s</text>' % (
                    x + w / 2, label_y + fs + 1, max(7.0, fs - 2), _fmt(r["w"]), _fmt(r["h"])))
            if r["parent"] is None and r["kind"] in ("living", "bedroom", "dining", "kitchen", "lounge", "study", "family", "balcony"):
                span = min(5.0, 0.5 * (r["h"] if r["x"] < 0.3 or r["x"] + r["w"] > W - 0.3 else r["w"]))
                if r["x"] < 0.3:
                    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#38bdf8" stroke-width="5"/>' % (
                        x, y + h / 2 - span * S / 2, x, y + h / 2 + span * S / 2))
                if r["x"] + r["w"] > W - 0.3:
                    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#38bdf8" stroke-width="5"/>' % (
                        x + w, y + h / 2 - span * S / 2, x + w, y + h / 2 + span * S / 2))
                if r["y"] < 0.3:
                    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#38bdf8" stroke-width="5"/>' % (
                        x + w / 2 - span * S / 2, y, x + w / 2 + span * S / 2, y))
                if r["y"] + r["h"] > D - 0.3:
                    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#38bdf8" stroke-width="5"/>' % (
                        x + w / 2 - span * S / 2, y + h, x + w / 2 + span * S / 2, y + h))
        # overall dimensions and the road side
        bx, by = ox0, oy + D * S
        o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#6b7280" stroke-width="1"/>' % (bx, by + 12, bx + W * S, by + 12))
        o.append('<text x="%.1f" y="%.1f" font-size="11" text-anchor="middle" fill="#374151">%s (front / road side)</text>' % (
            bx + W * S / 2, by + 26, _fmt(W)))
        o.append('<text x="%.1f" y="%.1f" font-size="11" text-anchor="middle" fill="#374151" transform="rotate(-90 %.1f %.1f)">%s</text>' % (
            bx + W * S + 18, oy + D * S / 2, bx + W * S + 18, oy + D * S / 2, _fmt(D)))
    o.append("</svg>")
    return "".join(o)


def summarize(plan):
    """Flat, JSON-friendly room list for the page (no geometry)."""
    out = []
    for fl in plan["floors"]:
        rooms = [{"name": r["name"], "size": "%s x %s" % (_fmt(r["w"]), _fmt(r["h"])), "area": r["area"]}
                 for r in fl["rooms"]]
        out.append({"floor": fl["name"], "rooms": rooms})
    return out


def generate_robust(bedrooms, bathrooms, stories, garage, total_sq_ft, seed=1, attempts=12):
    """Like generate_plan, but if this particular seed cannot be fitted, try the next
    few seeds. The seed actually used is in plan["seed"]. Raises PlanError if none work."""
    first = None
    for i in range(attempts):
        try:
            return generate_plan(bedrooms, bathrooms, stories, garage, total_sq_ft, int(seed) + i)
        except PlanError as exc:
            first = first or exc
    raise first
