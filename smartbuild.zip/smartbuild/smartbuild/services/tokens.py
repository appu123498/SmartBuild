"""Small HMAC-signed bearer tokens (stdlib only, no extra packages).

Token format:  base64url(json payload) + "." + base64url(HMAC-SHA256 signature)
The payload always contains an "exp" (unix seconds) field.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time


class TokenError(Exception):
    pass


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _key(secret: str) -> bytes:
    # Domain separation so the same SECRET_KEY is not used raw for signing.
    return hashlib.sha256(b"smartbuild-api-token:" + secret.encode("utf-8")).digest()


def make_token(payload: dict, secret: str, ttl_seconds: int, now: float | None = None) -> str:
    body = dict(payload)
    body["exp"] = int((time.time() if now is None else now) + ttl_seconds)
    raw = json.dumps(body, separators=(",", ":"), sort_keys=True).encode("utf-8")
    sig = hmac.new(_key(secret), raw, hashlib.sha256).digest()
    return _b64e(raw) + "." + _b64e(sig)


def read_token(token: str, secret: str, now: float | None = None) -> dict:
    try:
        raw_b64, sig_b64 = token.split(".")
        raw = _b64d(raw_b64)
        sig = _b64d(sig_b64)
    except Exception:
        raise TokenError("Malformed token")
    expected = hmac.new(_key(secret), raw, hashlib.sha256).digest()
    if not hmac.compare_digest(sig, expected):
        raise TokenError("Bad signature")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise TokenError("Malformed token")
    if not isinstance(payload, dict) or "exp" not in payload:
        raise TokenError("Malformed token")
    if (time.time() if now is None else now) > payload["exp"]:
        raise TokenError("Token expired")
    return payload
