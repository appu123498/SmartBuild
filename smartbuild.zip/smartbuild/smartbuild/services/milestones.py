"""Default payment milestones. These percentages are ASSUMED defaults based on
common practice; confirm them with a local contractor and edit as needed
(or override with settings.SMARTBUILD['MILESTONES'])."""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

DEFAULT_SPLIT = [
    ("Foundation", 15),
    ("Structure (columns, beams, slabs)", 30),
    ("Masonry and roofing", 20),
    ("Plumbing and electrical", 15),
    ("Finishing (plaster, flooring, paint)", 20),
]

PENDING, IN_PROGRESS, COMPLETED, APPROVED = "Pending", "In Progress", "Completed", "Approved"
OPEN_STATUSES = (PENDING, IN_PROGRESS)


def split_amount(total, split=None):
    """Split `total` across milestones; the last one absorbs rounding so the
    amounts always add up to exactly `total`."""
    split = list(split or DEFAULT_SPLIT)
    if not split:
        raise ValueError("Milestone split is empty")
    pct_sum = sum(Decimal(str(p)) for _, p in split)
    if pct_sum != Decimal(100):
        raise ValueError("Milestone percentages must add up to 100 (got %s)" % pct_sum)
    total = Decimal(str(total)).quantize(Decimal("0.01"), ROUND_HALF_UP)
    if total <= 0:
        raise ValueError("Total must be greater than zero")

    rows, allocated = [], Decimal("0.00")
    for i, (name, pct) in enumerate(split, start=1):
        pct = Decimal(str(pct))
        if i == len(split):
            amount = total - allocated
        else:
            amount = (total * pct / Decimal(100)).quantize(Decimal("0.01"), ROUND_HALF_UP)
        allocated += amount
        rows.append({"seq": i, "name": name, "percent_of_cost": pct, "amount": amount})
    return rows
