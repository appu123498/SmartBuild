"""Construction cost estimator (scikit-learn RandomForest).

Heavy imports (numpy/sklearn/joblib) happen lazily so importing this module
is cheap. If no saved model exists, one is trained on synthetic data on first
use and cached under smartbuild/ml_artifacts/.
"""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

FEATURES = ["bedrooms", "bathrooms", "stories", "garage", "total_sq_ft"]
# Inclusive input limits = the range the model was trained on.
LIMITS = {
    "bedrooms": (1, 8),
    "bathrooms": (1, 8),
    "stories": (1, 3),
    "garage": (0, 3),
    "total_sq_ft": (400, 6000),
}

ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "ml_artifacts"
MODEL_FILE = ARTIFACT_DIR / "cost_model.joblib"
META_FILE = ARTIFACT_DIR / "cost_model_meta.json"

_lock = threading.Lock()
_bundle = None


# ---------------------------------------------------------------- formatting
def format_inr(amount) -> str:
    """20,00,000 style grouping with the rupee sign."""
    n = int(round(float(amount)))
    sign = "-" if n < 0 else ""
    s = str(abs(n))
    if len(s) <= 3:
        return "%s₹%s" % (sign, s)
    head, tail = s[:-3], s[-3:]
    groups = []
    while len(head) > 2:
        groups.insert(0, head[-2:])
        head = head[:-2]
    if head:
        groups.insert(0, head)
    return "%s₹%s,%s" % (sign, ",".join(groups), tail)


def _round_money(x: float) -> int:
    return int(round(x / 1000.0)) * 1000


# ------------------------------------------------------------------ training
def train_bundle(rows, source: str, seed: int = 42) -> dict:
    import numpy as np
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import mean_absolute_error, r2_score
    from sklearn.model_selection import train_test_split

    if len(rows) < 30:
        raise ValueError("Need at least 30 rows to train (got %d)" % len(rows))

    X = np.array([[float(r[f]) for f in FEATURES] for r in rows])
    y = np.array([float(r["cost"]) for r in rows])
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=seed)

    model = RandomForestRegressor(n_estimators=200, min_samples_leaf=3, random_state=seed, n_jobs=1)
    model.fit(X_tr, y_tr)

    pred = model.predict(X_te)
    ratios = y_te / pred  # actual / predicted on held-out rows
    q10, q90 = (float(v) for v in np.quantile(ratios, [0.10, 0.90]))

    meta = {
        "version": "rf-%s-%s" % (source.split(":")[0], datetime.now().strftime("%Y%m%d")),
        "trained_on": source,
        "n_samples": len(rows),
        "n_test": int(len(y_te)),
        "mae": float(mean_absolute_error(y_te, pred)),
        "r2": float(r2_score(y_te, pred)),
        "mape": float(np.mean(np.abs(y_te - pred) / y_te)),
        "interval_q10": q10,
        "interval_q90": q90,
        "trained_at": datetime.now().isoformat(timespec="seconds"),
    }
    return {"model": model, "meta": meta}


def save_bundle(bundle: dict) -> None:
    import joblib
    try:
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        joblib.dump(bundle, MODEL_FILE)
        META_FILE.write_text(json.dumps(bundle["meta"], indent=2), encoding="utf-8")
    except OSError as exc:  # e.g. read-only filesystem: keep going in memory
        logger.warning("Could not save estimator model: %s", exc)


def set_bundle(bundle: dict) -> None:
    global _bundle
    with _lock:
        _bundle = bundle


def model_file_exists() -> bool:
    return MODEL_FILE.exists()


def _load_or_train() -> dict:
    import joblib
    if MODEL_FILE.exists():
        try:
            bundle = joblib.load(MODEL_FILE)
            if isinstance(bundle, dict) and "model" in bundle and "meta" in bundle:
                return bundle
        except Exception as exc:  # e.g. scikit-learn version changed
            logger.warning("Saved estimator unusable (%s); retraining.", exc)
    from .datagen import generate_synthetic
    bundle = train_bundle(generate_synthetic(), source="synthetic")
    save_bundle(bundle)
    return bundle


def get_bundle() -> dict:
    global _bundle
    with _lock:
        if _bundle is None:
            _bundle = _load_or_train()
        return _bundle


# ---------------------------------------------------------------- prediction
def _predict(model, rows):
    import numpy as np
    return model.predict(np.array(rows, dtype=float))


def _max_affordable_sq_ft(model, spec, budget):
    start, end = int(LIMITS["total_sq_ft"][0]), int(spec[4])
    grid = list(range(start, end + 1, 10))
    if not grid:
        return None
    preds = _predict(model, [[spec[0], spec[1], spec[2], spec[3], s] for s in grid])
    best = None
    for s, p in zip(grid, preds):
        if p <= budget:
            best = s
        else:
            break
    return best


def _feasibility(model, spec, pred, lo, hi, budget):
    b = float(budget)
    if b >= hi:
        status = "comfortable"
        note = "Your budget of %s covers the whole estimated range (%s to %s)." % (
            format_inr(b), format_inr(lo), format_inr(hi))
    elif b >= pred:
        status = "within_budget"
        note = "Your budget covers the typical estimate (%s) but could fall short at the upper end (%s)." % (
            format_inr(pred), format_inr(hi))
    elif b >= lo:
        status = "tight"
        note = "Your budget is below the typical estimate of %s. It is only realistic with economical finishes." % (
            format_inr(pred))
    else:
        status = "below_estimate"
        note = "Your budget of %s is below the estimated minimum of %s for this specification." % (
            format_inr(b), format_inr(lo))

    out = {"status": status, "note": note, "suggested_sq_ft": None, "alternatives": []}
    if status in ("tight", "below_estimate"):
        out["suggested_sq_ft"] = _max_affordable_sq_ft(model, spec, b)
        if out["suggested_sq_ft"]:
            out["note"] += " At the typical rate, this budget covers roughly %d sq ft with the other details unchanged." % (
                out["suggested_sq_ft"])
        alts = []
        if spec[2] > LIMITS["stories"][0]:
            alts.append(("1 fewer storey", [spec[0], spec[1], spec[2] - 1, spec[3], spec[4]]))
        if spec[3] > LIMITS["garage"][0]:
            alts.append(("1 fewer garage", [spec[0], spec[1], spec[2], spec[3] - 1, spec[4]]))
        for label, row in alts:
            cost = float(_predict(model, [row])[0])
            out["alternatives"].append({
                "change": label,
                "predicted_cost": _round_money(cost),
                "within_budget": cost <= b,
            })
    return out


def estimate(bedrooms, bathrooms, stories, garage, total_sq_ft, budget=None, bundle=None) -> dict:
    bundle = bundle or get_bundle()
    model, meta = bundle["model"], bundle["meta"]
    spec = [bedrooms, bathrooms, stories, garage, total_sq_ft]

    pred = float(_predict(model, [spec])[0])
    lo = min(pred * meta["interval_q10"], pred)
    hi = max(pred * meta["interval_q90"], pred)

    result = {
        "predicted_cost": _round_money(pred),
        "min_cost": _round_money(lo),
        "max_cost": _round_money(hi),
        "cost_per_sq_ft": int(round(pred / float(total_sq_ft))),
        "currency": "INR",
        "model": {k: meta[k] for k in ("version", "trained_on", "n_samples", "mae", "r2")},
        "disclaimer": "Indicative estimate only. Actual cost depends on finishes, site and material rates.",
        "feasibility": None,
    }
    if budget is not None:
        result["feasibility"] = _feasibility(
            model, spec, result["predicted_cost"], result["min_cost"], result["max_cost"], budget)
    return result
