"""Input validation helpers. Everything raises ApiError(400, ...)."""
from __future__ import annotations

import math
import re
from decimal import Decimal, InvalidOperation

from .errors import ApiError
from .services.estimator import LIMITS


def _blank(value) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def parse_int(value, name, lo=None, hi=None, required=True):
    if _blank(value):
        if required:
            raise ApiError(400, "%s is required" % name)
        return None
    if isinstance(value, bool):
        raise ApiError(400, "%s must be a whole number" % name)
    try:
        number = float(str(value).strip())
    except ValueError:
        raise ApiError(400, "%s must be a whole number" % name)
    if not math.isfinite(number) or number != int(number):
        raise ApiError(400, "%s must be a whole number" % name)
    number = int(number)
    if (lo is not None and number < lo) or (hi is not None and number > hi):
        raise ApiError(400, "%s must be between %s and %s" % (name, lo, hi))
    return number


def parse_float(value, name, lo=None, hi=None, required=True):
    if _blank(value):
        if required:
            raise ApiError(400, "%s is required" % name)
        return None
    if isinstance(value, bool):
        raise ApiError(400, "%s must be a number" % name)
    try:
        number = float(str(value).strip())
    except ValueError:
        raise ApiError(400, "%s must be a number" % name)
    if not math.isfinite(number):
        raise ApiError(400, "%s must be a number" % name)
    if (lo is not None and number < lo) or (hi is not None and number > hi):
        raise ApiError(400, "%s must be between %s and %s" % (name, lo, hi))
    return number


def parse_money(value, name, required=True):
    """Accepts 2500000, "25,00,000", "₹ 25,00,000" or "Rs. 2500000". Returns Decimal."""
    if _blank(value):
        if required:
            raise ApiError(400, "%s is required" % name)
        return None
    if isinstance(value, bool):
        raise ApiError(400, "%s must be an amount" % name)
    text = re.sub(r"(?i)(₹|rs\.?|inr|,|\s)", "", str(value))
    try:
        amount = Decimal(text)
    except InvalidOperation:
        raise ApiError(400, "%s must be an amount" % name)
    if not amount.is_finite() or amount <= 0 or amount > Decimal("9999999999"):
        raise ApiError(400, "%s must be a positive amount" % name)
    return amount


def parse_spec(data, need_garage=True):
    """Validate the five house-spec fields used by the estimator and matcher."""
    spec = {}
    for field in ("bedrooms", "bathrooms", "stories"):
        spec[field] = parse_int(data.get(field), field, *LIMITS[field])
    if need_garage:
        spec["garage"] = parse_int(data.get("garage"), "garage", *LIMITS["garage"])
    else:
        spec["garage"] = parse_int(data.get("garage"), "garage", *LIMITS["garage"], required=False) or 0
    spec["total_sq_ft"] = parse_float(data.get("total_sq_ft"), "total_sq_ft", *LIMITS["total_sq_ft"])
    return spec
