"""Smart Build Assistant - JSON API (all URLs are under /api/, see urls.py)."""
import random
import secrets
from decimal import Decimal

from django.conf import settings
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from login.models import Contractors, PlanDailyUpdates, ProjectRequirements, TableUser, WeeklyPayments

from .api import api, config, json_body
from .errors import ApiError
from .models import CostEstimate, Milestone
from .services import ai_clients, estimator, planner
from .services import milestones as ms_logic
from .services.passwords import verify_password
from .services.tokens import make_token
from .validation import parse_int, parse_money, parse_spec

ROLE_MODELS = {'user': TableUser, 'contractor': Contractors}
PAY_METHODS = {'upi': 'UPI', 'card': 'Card', 'netbanking': 'Net banking'}
MAX_MILESTONE_TOTAL = Decimal('99999999')   # tbl_weekly_payments.amount is decimal(10,2)
BIG = 10 ** 9


# ----------------------------------------------------------------- helpers
def _money(value):
    return None if value is None else float(value)


def _iso(dt):
    return dt.isoformat() if dt else None


def _media_url(request, name):
    return request.build_absolute_uri(settings.MEDIA_URL + str(name)) if name else None


def _ai_config():
    c = config()
    return ai_clients.AIConfig(hf_token=c['HF_TOKEN'], summary_model=c['SUMMARY_MODEL'])


def _get_requirement(rid):
    req = ProjectRequirements.objects.filter(pk=rid).first()
    if req is None:
        raise ApiError(404, 'Requirement / plan not found')
    return req


def _is_owner(req, user):
    return user.role == 'user' and str(req.user_id) == str(user.id)


def _is_contractor(req, user):
    return user.role == 'contractor' and str(req.contractor_id) == str(user.id)


def _can_view(req, user):
    return _is_owner(req, user) or _is_contractor(req, user)


def _requirement_budget(req):
    try:
        return parse_money(req.budget, 'budget', required=False)
    except ApiError:
        return None


def _milestone_json(m, updates=None, payment=None):
    out = {
        'id': m.id, 'requirement_id': m.requirement_id, 'seq': m.seq, 'name': m.name,
        'percent_of_cost': float(m.percent_of_cost), 'amount': _money(m.amount),
        'status': m.status, 'rejection_note': m.rejection_note,
        'completed_at': _iso(m.completed_at), 'approved_at': _iso(m.approved_at),
    }
    if updates is not None:
        out['updates'] = updates
    out['payment'] = _payment_json(payment) if payment is not None else None
    return out


def _update_json(request, u):
    return {
        'id': u.id, 'plan_id': int(u.plan_id), 'milestone_id': u.milestone_id,
        'posted_by': u.user_type, 'text': u.text, 'summary': u.summary,
        'transcript': u.transcript, 'date': _iso(u.date),
    }


def _payment_json(p):
    return {'id': p.id, 'plan_id': int(p.plan_id), 'milestone_id': p.milestone_id,
            'amount': _money(p.amount), 'status': p.status, 'payment_date': str(p.payment_date),
            'method': p.method, 'txn_ref': p.txn_ref, 'paid_at': _iso(p.paid_at),
            'category': p.category, 'label': p.label}


def _estimate_json(e):
    return {
        'requirement_id': e.requirement_id, 'predicted_cost': _money(e.predicted_cost),
        'min_cost': _money(e.min_cost), 'max_cost': _money(e.max_cost), 'budget': _money(e.budget),
        'feasibility': {'status': e.feasibility, 'note': e.feasibility_note,
                        'suggested_sq_ft': e.suggested_sq_ft},
        'model_version': e.model_version, 'created_at': _iso(e.created_at),
    }


def _resolve_milestone(rid, milestone_id):
    """Explicit milestone_id -> validate it; otherwise the current open milestone (or None)."""
    qs = Milestone.objects.filter(requirement_id=rid).order_by('seq')
    if milestone_id is not None:
        m = qs.filter(pk=milestone_id).first()
        if m is None:
            raise ApiError(404, 'Milestone not found for this plan')
        if m.status == ms_logic.APPROVED:
            raise ApiError(409, 'That milestone is already approved')
        return m
    return qs.filter(status__in=ms_logic.OPEN_STATUSES).first()


# -------------------------------------------------------------------- misc
@api(['GET'])
def health(request):
    ai = _ai_config()
    return {'ok': True, 'summary_configured': ai.summary_enabled,
            'estimator_model_saved': estimator.model_file_exists()}


@api(['POST'])
def auth_login(request):
    data = json_body(request)
    role = str(data.get('role') or '').strip().lower()
    identifier = str(data.get('identifier') or data.get('phone') or data.get('email') or '').strip()
    password = str(data.get('password') or '')
    if role not in ROLE_MODELS:
        raise ApiError(400, 'role must be one of: %s' % ', '.join(sorted(ROLE_MODELS)))
    if not identifier or not password:
        raise ApiError(400, 'identifier (phone or email) and password are required')
    candidates = ROLE_MODELS[role].objects.filter(Q(phone=identifier) | Q(email__iexact=identifier))[:5]
    for account in candidates:
        if verify_password(password, account.password):
            ttl = config()['TOKEN_TTL_SECONDS']
            token = make_token({'role': role, 'id': account.id, 'name': account.name}, settings.SECRET_KEY, ttl)
            return {'token': token, 'role': role, 'id': account.id, 'name': account.name, 'expires_in': ttl}
    raise ApiError(401, 'Invalid credentials')


# ---------------------------------------------------------- cost estimate
@api(['POST'], roles=['user'])
def estimate_cost(request):
    data = json_body(request)
    spec = parse_spec(data)
    budget = parse_money(data.get('budget'), 'budget', required=False)
    rid = parse_int(data.get('requirement_id'), 'requirement_id', 1, BIG, required=False)

    req = None
    if rid:
        req = _get_requirement(rid)
        if not _is_owner(req, request.api_user):
            raise ApiError(403, 'This requirement belongs to another user')
        if budget is None:
            budget = _requirement_budget(req)

    result = estimator.estimate(budget=budget, **spec)
    result['saved'] = False
    if req is not None:
        f = result['feasibility']
        CostEstimate.objects.create(
            requirement_id=req.id, user_id=request.api_user.id, budget=budget,
            predicted_cost=result['predicted_cost'], min_cost=result['min_cost'], max_cost=result['max_cost'],
            feasibility=f['status'] if f else None, feasibility_note=(f['note'] if f else None) and f['note'][:500],
            suggested_sq_ft=f['suggested_sq_ft'] if f else None, model_version=result['model']['version'])
        result['saved'] = True
    return result


@api(['GET'], roles=['user', 'contractor'])
def estimate_saved(request, rid):
    req = _get_requirement(rid)
    if not _can_view(req, request.api_user):
        raise ApiError(403, 'You do not have access to this plan')
    est = CostEstimate.objects.filter(requirement_id=rid).order_by('-id').first()
    if est is None:
        raise ApiError(404, 'No saved estimate for this plan')
    return _estimate_json(est)


# ---------------------------------------------------------------- my plans
@api(['GET'], roles=['user', 'contractor'])
def my_plans(request):
    """Plans (project requirements) that belong to / are assigned to the caller."""
    user = request.api_user
    if user.role == 'user':
        rows = ProjectRequirements.objects.filter(user_id=str(user.id))
    else:
        rows = ProjectRequirements.objects.filter(contractor_id=str(user.id))
    return {'plans': [{
        'id': r.id, 'plan_name': r.plan_name or '', 'status': r.requirement_status,
        'budget': str(r.budget) if r.budget is not None else None,
        'bedrooms': r.bedrooms, 'bathrooms': r.bathrooms, 'stories': r.stories,
        'total_sq_ft': str(r.total_sq_ft) if r.total_sq_ft is not None else None,
    } for r in rows.order_by('-id')]}


# ----------------------------------------------------------- AI plan design
@api(['POST'])
def plan_generate(request):
    """Public (the home page uses it without a login). Body: bedrooms, bathrooms,
    stories, garage, total_sq_ft, [budget], [seed]. Returns an SVG floor plan,
    a room list and the cost estimate."""
    data = json_body(request)
    spec = parse_spec(data)
    budget = parse_money(data.get('budget'), 'budget', required=False)
    seed = parse_int(data.get('seed'), 'seed', 0, 2 ** 31 - 1, required=False)
    if seed is None:
        seed = random.randint(1, 999999)
    try:
        plan = planner.generate_robust(seed=seed, **spec)
    except planner.PlanError as exc:
        raise ApiError(422, str(exc))
    return {
        'seed': plan['seed'], 'svg': planner.render_svg(plan), 'floors': planner.summarize(plan),
        'plot': plan['plot'], 'estimate': estimator.estimate(budget=budget, **spec),
        'disclaimer': 'Concept layout generated by a rule-based algorithm. It is not an approved drawing: '
                      'an architect or structural engineer must prepare the real plans.',
    }


# --------------------------------------------------------------- milestones
@api(['POST'], roles=['contractor'])
def milestones_generate(request, rid):
    req = _get_requirement(rid)
    if not _is_contractor(req, request.api_user):
        raise ApiError(403, 'You are not the contractor assigned to this plan')
    if req.requirement_status != 'Plan Accepted':
        raise ApiError(409, 'Milestones can start only after the client accepts the plan (status: %s)' % req.requirement_status)
    if Milestone.objects.filter(requirement_id=rid).exists():
        raise ApiError(409, 'Milestones already exist for this plan')

    data = json_body(request)
    total, basis = parse_money(data.get('total_amount'), 'total_amount', required=False), 'total_amount'
    if total is None:
        est = CostEstimate.objects.filter(requirement_id=rid).order_by('-id').first()
        if est is not None:
            total, basis = est.predicted_cost, 'estimate'
    if total is None:
        total, basis = _requirement_budget(req), 'budget'
    if total is None:
        raise ApiError(400, 'No amount available. Send total_amount, or save a cost estimate first.')
    if total > MAX_MILESTONE_TOTAL:
        raise ApiError(400, 'total_amount is too large (maximum %s)' % MAX_MILESTONE_TOTAL)

    rows = ms_logic.split_amount(total, config().get('MILESTONES'))
    with transaction.atomic():
        Milestone.objects.bulk_create([Milestone(requirement_id=rid, **row) for row in rows])
    # bulk_create does not always return primary keys on MySQL; re-read for a reliable response
    saved = Milestone.objects.filter(requirement_id=rid).order_by('seq')
    return {'requirement_id': rid, 'basis': basis, 'total': _money(total),
            'milestones': [_milestone_json(m) for m in saved]}, 201


@api(['GET'], roles=['user', 'contractor'])
def milestones_list(request, rid):
    req = _get_requirement(rid)
    if not _can_view(req, request.api_user):
        raise ApiError(403, 'You do not have access to this plan')
    milestones = list(Milestone.objects.filter(requirement_id=rid).order_by('seq'))
    grouped = {}
    for u in PlanDailyUpdates.objects.filter(plan_id=str(rid), milestone_id__isnull=False).order_by('-date', '-id'):
        bucket = grouped.setdefault(u.milestone_id, [])
        if len(bucket) < 5:
            bucket.append({'id': u.id, 'date': _iso(u.date), 'posted_by': u.user_type, 'summary': u.summary or u.text})
    approved = sum(float(m.percent_of_cost) for m in milestones if m.status == ms_logic.APPROVED)
    payments = {p.milestone_id: p for p in WeeklyPayments.objects.filter(milestone_id__in=[m.id for m in milestones])}
    return {
        'requirement_id': rid,
        'total': _money(sum((m.amount for m in milestones), Decimal('0'))),
        'progress_percent': approved,
        'milestones': [_milestone_json(m, grouped.get(m.id, []), payments.get(m.id)) for m in milestones],
    }


def _milestone_for(mid):
    m = Milestone.objects.filter(pk=mid).first()
    if m is None:
        raise ApiError(404, 'Milestone not found')
    return m, _get_requirement(m.requirement_id)


@api(['POST'], roles=['contractor'])
def milestone_complete(request, mid):
    m, req = _milestone_for(mid)
    if not _is_contractor(req, request.api_user):
        raise ApiError(403, 'You are not the contractor assigned to this plan')
    if m.status not in ms_logic.OPEN_STATUSES:
        raise ApiError(409, 'Milestone is already %s' % m.status)
    if not PlanDailyUpdates.objects.filter(plan_id=str(m.requirement_id), milestone_id=m.id).exists():
        raise ApiError(400, 'Post at least one daily update for this milestone before marking it complete')
    changed = Milestone.objects.filter(pk=m.pk, status__in=ms_logic.OPEN_STATUSES).update(
        status=ms_logic.COMPLETED, completed_at=timezone.now(), rejection_note=None)
    if not changed:
        raise ApiError(409, 'Milestone was changed by someone else; reload and try again')
    return {'milestone': _milestone_json(Milestone.objects.get(pk=m.pk))}


@api(['POST'], roles=['user'])
def milestone_approve(request, mid):
    m, req = _milestone_for(mid)
    if not _is_owner(req, request.api_user):
        raise ApiError(403, 'This plan belongs to another user')
    if m.status != ms_logic.COMPLETED:
        raise ApiError(409, 'Only a milestone marked Completed by the contractor can be approved (current: %s)' % m.status)
    with transaction.atomic():
        changed = Milestone.objects.filter(pk=m.pk, status=ms_logic.COMPLETED).update(
            status=ms_logic.APPROVED, approved_at=timezone.now())
        if not changed:
            raise ApiError(409, 'Milestone was changed by someone else; reload and try again')
        payment = WeeklyPayments.objects.create(
            plan_id=str(m.requirement_id), payment_date=str(timezone.localdate()),
            amount=m.amount, status='pending', milestone_id=m.id)
        done = not Milestone.objects.filter(requirement_id=m.requirement_id).exclude(status=ms_logic.APPROVED).exists()
        if done:
            ProjectRequirements.objects.filter(pk=m.requirement_id).update(requirement_status='Completed')
    return {'milestone': _milestone_json(Milestone.objects.get(pk=m.pk)),
            'payment': _payment_json(payment), 'project_completed': done}


@api(['POST'], roles=['user'])
def milestone_reject(request, mid):
    m, req = _milestone_for(mid)
    if not _is_owner(req, request.api_user):
        raise ApiError(403, 'This plan belongs to another user')
    note = str(json_body(request).get('note') or '').strip()
    if not note:
        raise ApiError(400, 'note is required so the contractor knows what to fix')
    if m.status != ms_logic.COMPLETED:
        raise ApiError(409, 'Only a Completed milestone can be sent back (current: %s)' % m.status)
    changed = Milestone.objects.filter(pk=m.pk, status=ms_logic.COMPLETED).update(
        status=ms_logic.IN_PROGRESS, rejection_note=note[:255], completed_at=None)
    if not changed:
        raise ApiError(409, 'Milestone was changed by someone else; reload and try again')
    return {'milestone': _milestone_json(Milestone.objects.get(pk=m.pk))}


# ------------------------------------------------- labour / material charges
MAX_CHARGE = Decimal('9999999')   # tbl_weekly_payments.amount is decimal(10,2)


@api(['POST'], roles=['contractor'])
def charge_create(request, rid):
    """A one-off bill for labour or materials, outside the 5 fixed stages.
    Body: {"label": "...", "amount": 15000}"""
    req = _get_requirement(rid)
    if not _is_contractor(req, request.api_user):
        raise ApiError(403, 'You are not the contractor assigned to this plan')
    if req.requirement_status not in ('Plan Accepted', 'Completed'):
        raise ApiError(409, 'Charges can be raised only once the client has accepted the plan')
    data = json_body(request)
    label = str(data.get('label') or '').strip()
    if not label:
        raise ApiError(400, 'label is required, e.g. "Labour: site clearing, 4 workers x 2 days"')
    if len(label) > 150:
        raise ApiError(400, 'label is too long (150 characters maximum)')
    amount = parse_money(data.get('amount'), 'amount')
    if amount > MAX_CHARGE:
        raise ApiError(400, 'amount is too large (maximum %s)' % MAX_CHARGE)
    payment = WeeklyPayments.objects.create(
        plan_id=str(rid), payment_date=str(timezone.localdate()), amount=amount, status='pending',
        milestone_id=None, category='labour', label=label[:150])
    return {'payment': _payment_json(payment)}, 201


# ----------------------------------------------------------------- payments
@api(['POST'], roles=['user'])
def payment_pay(request, pid):
    """Demo checkout: records a payment. No real money moves; plug a real gateway in here later."""
    method = str(json_body(request).get('method') or '').strip().lower()
    if method not in PAY_METHODS:
        raise ApiError(400, 'method must be one of: %s' % ', '.join(sorted(PAY_METHODS)))
    payment = WeeklyPayments.objects.filter(pk=pid).first()
    if payment is None:
        raise ApiError(404, 'Payment not found')
    try:
        req = _get_requirement(int(payment.plan_id))
    except ValueError:
        raise ApiError(404, 'Payment is not linked to a plan')
    if not _is_owner(req, request.api_user):
        raise ApiError(403, 'This payment belongs to another user')
    if payment.status != 'pending':
        raise ApiError(409, 'Payment is already %s' % payment.status)
    now = timezone.now()
    txn = 'TXN%s%s' % (now.strftime('%y%m%d%H%M%S'), secrets.token_hex(3).upper())
    changed = WeeklyPayments.objects.filter(pk=pid, status='pending').update(
        status='paid', method=method, txn_ref=txn, paid_at=now)
    if not changed:
        raise ApiError(409, 'Payment was changed by someone else; reload and try again')
    return {'payment': _payment_json(WeeklyPayments.objects.get(pk=pid))}


# ------------------------------------------------------------ daily updates
@api(['POST'], roles=['contractor'])
def post_update(request):
    """Daily update from the contractor. JSON/form fields: plan_id, text, [milestone_id].

    `text` is typed, or dictated in the browser (speech recognition happens
    in the browser, so no speech API key is needed). If a Hugging Face token
    is configured the text is also translated/summarised into short English.
    """
    user = request.api_user
    data = json_body(request)
    rid = parse_int(data.get('plan_id'), 'plan_id', 1, BIG)
    req = _get_requirement(rid)
    if not _is_contractor(req, user):
        raise ApiError(403, 'You are not the contractor assigned to this plan')

    milestone = _resolve_milestone(rid, parse_int(data.get('milestone_id'), 'milestone_id', 1, BIG, required=False))
    text = str(data.get('text') or '').strip()
    if not text:
        raise ApiError(400, 'text is required')
    if len(text) > 5000:
        raise ApiError(400, 'text is too long (maximum 5000 characters)')

    cfg, warnings, summary = _ai_config(), [], None
    if cfg.summary_enabled:
        try:
            summary = ai_clients.summarize(cfg, text)
        except ai_clients.AIServiceError as exc:
            warnings.append('%s The update was saved without an AI summary.' % exc)

    with transaction.atomic():
        update = PlanDailyUpdates.objects.create(
            plan_id=str(rid), text=(summary or text)[:255],
            user_type=('contractor :%s' % user.name)[:50],
            date=timezone.now(), milestone_id=milestone.id if milestone else None,
            transcript=text, summary=summary)
        if milestone is not None and milestone.status == ms_logic.PENDING:
            Milestone.objects.filter(pk=milestone.pk, status=ms_logic.PENDING).update(status=ms_logic.IN_PROGRESS)
    result = _update_json(request, update)
    result['warnings'] = warnings
    return result, 201


@api(['GET'], roles=['user', 'contractor'])
def updates_list(request, rid):
    req = _get_requirement(rid)
    if not _can_view(req, request.api_user):
        raise ApiError(403, 'You do not have access to this plan')
    rows = PlanDailyUpdates.objects.filter(plan_id=str(rid)).order_by('-date', '-id')[:50]
    return {'plan_id': rid, 'updates': [_update_json(request, u) for u in rows]}
