import csv

from django.core.management.base import BaseCommand, CommandError

from smartbuild.services import estimator
from smartbuild.services.datagen import ASSUMPTIONS, generate_synthetic


class Command(BaseCommand):
    help = ("Train the construction cost estimator and save it. With no options it uses SYNTHETIC "
            "placeholder data. Use --csv with real past-project costs for a meaningful accuracy figure.")

    def add_arguments(self, parser):
        parser.add_argument('--csv', help='CSV with columns: bedrooms,bathrooms,stories,garage,total_sq_ft,cost')
        parser.add_argument('--rows', type=int, default=3000, help='synthetic rows (default 3000)')
        parser.add_argument('--seed', type=int, default=42)

    def handle(self, *args, **opts):
        if opts['csv']:
            rows, source = self._read_csv(opts['csv']), 'csv:' + opts['csv'].replace('\\', '/').split('/')[-1]
            if len(rows) < 100:
                self.stdout.write(self.style.WARNING(
                    'Only %d rows: with so little data the accuracy figures below are unreliable.' % len(rows)))
        else:
            rows, source = generate_synthetic(opts['rows'], opts['seed']), 'synthetic'
            self.stdout.write(self.style.WARNING(
                'Using SYNTHETIC data built from placeholder assumptions: %s' % ASSUMPTIONS))

        try:
            bundle = estimator.train_bundle(rows, source=source, seed=opts['seed'])
        except ValueError as exc:
            raise CommandError(str(exc))
        estimator.save_bundle(bundle)
        m = bundle['meta']
        self.stdout.write(self.style.SUCCESS('Model saved: %s' % estimator.MODEL_FILE))
        self.stdout.write('trained on : %s (%d rows, %d held out for testing)' % (m['trained_on'], m['n_samples'], m['n_test']))
        self.stdout.write('test MAE   : %s' % estimator.format_inr(m['mae']))
        self.stdout.write('test R2     : %.3f' % m['r2'])
        self.stdout.write('test MAPE   : %.1f%%' % (m['mape'] * 100))
        self.stdout.write('80%% range   : x%.2f to x%.2f of the typical estimate' % (m['interval_q10'], m['interval_q90']))
        if source == 'synthetic':
            self.stdout.write(self.style.WARNING(
                'These scores measure how well the model learned the synthetic rules, NOT real-world accuracy.'))

    def _read_csv(self, path):
        required = estimator.FEATURES + ['cost']
        try:
            with open(path, newline='', encoding='utf-8-sig') as fh:
                reader = csv.DictReader(fh)
                missing = [c for c in required if c not in (reader.fieldnames or [])]
                if missing:
                    raise CommandError('CSV is missing columns: %s' % ', '.join(missing))
                rows = []
                for n, row in enumerate(reader, start=2):
                    try:
                        parsed = {c: float(row[c]) for c in required}
                    except (TypeError, ValueError):
                        raise CommandError('Row %d has a non-numeric value' % n)
                    lo_hi_ok = all(estimator.LIMITS[f][0] <= parsed[f] <= estimator.LIMITS[f][1] for f in estimator.FEATURES)
                    if parsed['cost'] <= 0 or not lo_hi_ok:
                        raise CommandError('Row %d is outside the supported ranges %s (cost must be > 0)' % (n, estimator.LIMITS))
                    rows.append(parsed)
                return rows
        except OSError as exc:
            raise CommandError('Cannot read %s: %s' % (path, exc))
