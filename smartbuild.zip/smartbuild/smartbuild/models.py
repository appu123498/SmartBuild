from django.db import models
from django.utils.timezone import now

# Tables are created by sql/smartbuild_schema.sql (same approach as the rest of
# this project: MySQL tables made outside Django, so managed = False).


class CostEstimate(models.Model):
    requirement_id = models.IntegerField(null=True, blank=True)
    user_id = models.IntegerField()
    budget = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    predicted_cost = models.DecimalField(max_digits=12, decimal_places=2)
    min_cost = models.DecimalField(max_digits=12, decimal_places=2)
    max_cost = models.DecimalField(max_digits=12, decimal_places=2)
    feasibility = models.CharField(max_length=20, null=True, blank=True)
    feasibility_note = models.CharField(max_length=500, null=True, blank=True)
    suggested_sq_ft = models.IntegerField(null=True, blank=True)
    model_version = models.CharField(max_length=50, null=True, blank=True)
    created_at = models.DateTimeField(default=now)

    class Meta:
        db_table = 'tbl_cost_estimates'
        managed = False


class Milestone(models.Model):
    requirement_id = models.IntegerField()
    seq = models.IntegerField()
    name = models.CharField(max_length=100)
    percent_of_cost = models.DecimalField(max_digits=5, decimal_places=2)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, default='Pending')
    rejection_note = models.CharField(max_length=255, null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=now)

    class Meta:
        db_table = 'tbl_milestones'
        managed = False
        ordering = ['requirement_id', 'seq']
