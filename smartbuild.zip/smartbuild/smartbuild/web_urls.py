from django.urls import path

from . import web

urlpatterns = [
    path('milestones/', web.milestones_page, name='smart_milestones'),
]
