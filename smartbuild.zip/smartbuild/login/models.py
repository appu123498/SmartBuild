from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils.timezone import now


# Create your models here.

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(email, password, **extra_fields)


# Custom user model
class User(AbstractUser):
    email = models.EmailField(unique=True)  
    phone = models.CharField(max_length=15, null=True, blank=True)
    fullname = models.CharField(max_length=100, null=True, blank=True)
    address = models.TextField()
    profile = models.ImageField(upload_to="profile/")
    role = models.CharField(max_length=100, null=True, blank=True)
    username = None

    objects = CustomUserManager()

    class Meta:
        db_table = 'user'

    def __str__(self):
        return self.fullname or self.email  # fullname can be empty (e.g. the admin account)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

class TableUser(models.Model):
    # id = models.AutoField(primary_key=True)  
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    created_at = models.DateTimeField()

    class Meta:
        db_table = 'tbl_users'
        managed = False

    def __str__(self):
        return self.name
    

class TableRequirements(models.Model):
    # id = models.AutoField(primary_key=True)  
    user_id = models.CharField(max_length=50)
    designer_id = models.CharField(max_length=50)
    contractor_id = models.CharField(max_length=50)
    bedrooms = models.CharField(max_length=50)
    bathrooms = models.CharField(max_length=50)
    garage = models.CharField(max_length=50)
    stories = models.CharField(max_length=50)
    total_sq_ft = models.CharField(max_length=50)
    requirement_status = models.CharField(max_length=50)
    plan_name = models.CharField(max_length=50)
    plan_file = models.CharField(max_length=100)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

    class Meta:
        db_table = 'tbl_requirements'
        managed = False


class ProjectRequirements(models.Model):
    # id = models.AutoField(primary_key=True)  
    user_id = models.CharField(max_length=50)
    designer_id = models.CharField(max_length=50)
    contractor_id = models.CharField(max_length=50)
    bedrooms = models.CharField(max_length=50)
    bathrooms = models.CharField(max_length=50)
    garage = models.CharField(max_length=50)
    stories = models.CharField(max_length=50)
    total_sq_ft = models.CharField(max_length=50)
    requirement_status = models.CharField(max_length=50)
    plan_name = models.CharField(max_length=50)
    plan_file = models.FileField(upload_to="plan/")
    budget = models.CharField(max_length=50)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

    class Meta:
        db_table = 'tbl_project_requirements'
        managed = False



class PlanDailyUpdates(models.Model):
    # id = models.AutoField(primary_key=True)  
    plan_id = models.CharField(max_length=50)
    text = models.CharField(max_length=255)
    # tbl_plan_daily_updates.user_type is NOT NULL with no default in the database,
    # so it must be part of the model or inserts fail in strict mode.
    user_type = models.CharField(max_length=50, default='')
    date = models.DateTimeField(default=now)
    # --- Smart Build Assistant columns (added by sql/smartbuild_schema.sql) ---
    milestone_id = models.IntegerField(null=True, blank=True)
    transcript = models.TextField(null=True, blank=True)
    summary = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'tbl_plan_daily_updates'
        managed = False


class Employees(models.Model):
    # id = models.AutoField(primary_key=True) 
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    plan = models.CharField(max_length=100)
    type = models.CharField(max_length=100, null=True,blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'tbl_employees'
        managed = False


class Designers(models.Model):
    # id = models.AutoField(primary_key=True)  
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'tbl_designers'
        managed = False


class DesignersWork(models.Model):
    # id = models.AutoField(primary_key=True)  
    designer_id = models.CharField(max_length=50)
    description = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    work_image = models.ImageField(upload_to="work/")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'tbl_designers_works'
        managed = False


class Contractors(models.Model):
    # id = models.AutoField(primary_key=True)  
    name = models.CharField(max_length=100)
    company_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'tbl_contractors'
        managed = False


class WeeklyPayments(models.Model):
    # id = models.AutoField(primary_key=True)  
    plan_id = models.CharField(max_length=100)
    payment_date = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    milestone_id = models.IntegerField(null=True, blank=True)   # Smart Build Assistant
    method = models.CharField(max_length=30, null=True, blank=True)    # upi / card / netbanking
    txn_ref = models.CharField(max_length=40, null=True, blank=True)   # payment reference
    paid_at = models.DateTimeField(null=True, blank=True)
    category = models.CharField(max_length=20, default='milestone')    # 'milestone' or 'labour'
    label = models.CharField(max_length=150, null=True, blank=True)    # description for a labour/material charge

    class Meta:
        db_table = 'tbl_weekly_payments'
        managed = False

# models.py

from django.db import models

class ProjectRequirement(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    designer_id = models.IntegerField()
    contractor_id = models.IntegerField()
    plan_name = models.CharField(max_length=255)
    plan_file = models.FileField(upload_to='plans/')
    requirement_status = models.CharField(max_length=100)  # was misspelled 'reqirement_status' -> no such column
    budget = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        db_table = 'tbl_project_requirements'  # Link to the existing table
        managed = False  # table already exists; avoids a duplicate CREATE TABLE in makemigrations

    def __str__(self):
        return self.plan_name











# class CustomUserManager(BaseUserManager):
#     def create_user(self, email, password=None, **extra_fields):
#         if not email:
#             raise ValueError("The Email field must be set")
#         email = self.normalize_email(email)
#         user = self.model(email=email, **extra_fields)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, email, password=None, **extra_fields):
#         extra_fields.setdefault("is_staff", True)
#         extra_fields.setdefault("is_superuser", True)

#         if extra_fields.get("is_staff") is not True:
#             raise ValueError("Superuser must have is_staff=True.")
#         if extra_fields.get("is_superuser") is not True:
#             raise ValueError("Superuser must have is_superuser=True.")

#         return self.create_user(email, password, **extra_fields)


# # Custom user model
# class User(AbstractUser):
#     email = models.EmailField(unique=True)  
#     phone = models.CharField(max_length=15, null=True, blank=True)
#     fullname = models.CharField(max_length=100, null=True, blank=True)
#     address = models.TextField()
#     profile = models.ImageField(upload_to="user_profile/")
#     username = None

#     objects = CustomUserManager()

#     class Meta:
#         db_table = 'user'

#     def __str__(self):
#         return self.fullname

#     USERNAME_FIELD = "email"
#     REQUIRED_FIELDS = []


# class WorkerTable(models.Model):
#     username = models.CharField(max_length=100, null=True, blank=True)
#     fullname = models.CharField(max_length=100, null=True, blank=True)
#     address = models.TextField()
#     phone = models.CharField(max_length=15, null=True, blank=True)
#     profile = models.ImageField(upload_to="worker_profile/")
#     email = models.EmailField(unique=True)
#     date_joined = models.DateTimeField(default=now, editable=False) 
#     password = models.CharField(max_length=100, null=True, blank=True)

#     class Meta:
#         db_table = 'worker_table'

#     def __str__(self):
#         return self.fullname


# class ContractorTable(models.Model):
#     username = models.CharField(max_length=100, null=True, blank=True)
#     fullname = models.CharField(max_length=100, null=True, blank=True)
#     address = models.TextField()
#     phone = models.CharField(max_length=15, null=True, blank=True)
#     profile = models.ImageField(upload_to="contractor_profile/")
#     email = models.EmailField(unique=True)
#     date_joined = models.DateTimeField(default=now, editable=False) 
#     password = models.CharField(max_length=100, null=True, blank=True)

#     class Meta:
#         db_table = 'contractor_table'

#     def __str__(self):
#         return self.fullname


# class DesignerTable(models.Model):
#     username = models.CharField(max_length=100, null=True, blank=True)
#     fullname = models.CharField(max_length=100, null=True, blank=True)
#     address = models.TextField()
#     phone = models.CharField(max_length=15, null=True, blank=True)
#     profile = models.ImageField(upload_to="designer_profile/")
#     email = models.EmailField(unique=True)
#     date_joined = models.DateTimeField(default=now, editable=False) 
#     password = models.CharField(max_length=100, null=True, blank=True)

#     class Meta:
#         db_table = 'designer_table'

#     def __str__(self):
#         return self.fullname


# class DesignsTable(models.Model):
#     designer_id = models.ForeignKey(DesignerTable, on_delete=models.CASCADE, related_name='designer_works')
#     name = models.CharField(max_length=100)
#     description = models.TextField(blank=True)

#     class Meta:
#         db_table = 'designer_work_table'

#     def __str__(self):
#         return f"{self.name} by {self.designer_id.fullname}"
    

# class DesignsTableImage(models.Model):
#     designer_work = models.ForeignKey(DesignsTable, on_delete=models.CASCADE, related_name='images')
#     image = models.ImageField(upload_to='designer_work_images/')

#     class Meta:
#         db_table = 'designer_work_image_table'

#     def __str__(self):
#         return f"Image for {self.designer_work.name}"
    

# class PreviousDesign(models.Model):
#     designer_id = models.ForeignKey(DesignerTable, on_delete=models.CASCADE, related_name='previous_design')
#     name = models.CharField(max_length=100, null=True, blank=True)
#     description = models.TextField(blank=True)

#     class Meta:
#         db_table = 'previous_designs'

#     def __str__(self):
#         return f"Image for {self.designer_id.fullname}"


# class DesignerPreviousWorkImage(models.Model):
#     designer_previous_work = models.ForeignKey(PreviousDesign, on_delete=models.CASCADE, related_name='images')
#     image = models.ImageField(upload_to='designer_previous_work_images/')

#     class Meta:
#         db_table = 'designer_previous_work_image'

#     def __str__(self):
#         return f"Image for {self.designer_previous_work.name}"


# class WorksTable(models.Model):
#     worker_id = models.ForeignKey(WorkerTable, on_delete=models.CASCADE, related_name='worker_works')
#     work = models.CharField(max_length=100, null=True, blank=True)
#     date = models.DateTimeField()

#     class Meta:
#         db_table = 'works_table'
    
#     def __str__(self):
#         return f'{self.worker_id.fullname} - {self.work}'
    

# class Plan(models.Model):
#     image = models.ImageField(upload_to="plans/")
#     name = models.CharField(max_length=100, null=True, blank=True)

#     class Meta:
#         db_table = 'plan_table'
    
#     def __str__(self):
#         return self.name


# class Payments(models.Model):
#     worker = models.ForeignKey(WorkerTable, on_delete=models.CASCADE)
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     work_name = models.CharField(max_length=100, null=True, blank=True)
#     amount = models.DecimalField(max_digits=10, decimal_places=2)

#     class Meta:
#         db_table = 'payment'
    
#     def __str__(self):
#         return f"{self.work_name} - {self.amount}"