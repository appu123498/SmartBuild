from django import forms
from .models import *

class ConstructorForm(forms.ModelForm):
    class Meta:
        model = Contractors
        fields = ['name', 'company_name', 'email', 'phone', 'password']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Username'}),
            'company_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Full Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone Number'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter Password'})

        }
   

class DesignerForm(forms.ModelForm):
    class Meta:
        model = Designers
        fields = ['name', 'email', 'phone', 'password']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Full Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone Number'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter Password'})
        }


class WorkerForm(forms.ModelForm):
    class Meta:
        model = Employees
        fields = ['name', 'email', 'phone', 'type', 'password']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Username'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone Number'}),
            'type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Type'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter Password'})
        }


class DesignForm(forms.ModelForm):
    class Meta:
        model = DesignersWork
        fields = ['work_image','title', 'description']
        widgets = {
            'work_image': forms.FileInput(attrs={'class': 'form-control', 'placeholder': 'Select Your Image'}),
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Title'}),
            'description': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Description '}),
        }