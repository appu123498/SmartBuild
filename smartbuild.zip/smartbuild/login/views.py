from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib import messages
from . models import *
from . forms import *
from django.contrib.auth.hashers import check_password

# Create your views here.


def dashboard(request):
    result = TableUser.objects.all()
    return render(request, 'list_user.html', {'result': result})


def login(request):
    """The old combined admin/designer login lives on the website home page now."""
    return redirect('/portal/login/?role=admin')


# logout
def signout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')



def contractor(request):
    result = Contractors.objects.all()
    return render(request, 'list_contractor.html', {'result': result})


def add_contractor(request):
    if request.method == "POST":
        form = ConstructorForm(request.POST, request.FILES)  
        if form.is_valid():
            constructor = form.save(commit=False)
            constructor.save()  
            messages.success(request, "Contractor user added successfully.")
            return redirect('contractor')  
        else:
            messages.error(request, "There was an error with your submission.")
    else:
        form = ConstructorForm()

    return render(request, 'add_constructor.html', {'form': form})


def delete_contractor(request, id):
    contractor = get_object_or_404(Contractors, id=id)
    
    if request.method == "POST":
        # Delete the record
        contractor.delete()
        messages.success(request, "Contractor record deleted successfully!")
        return redirect('contractor')  
    # a GET request (e.g. typing the URL) must also return a response
    return redirect('contractor')

    
def designers(request):
    result = Designers.objects.all()
    return render(request, 'list_designers.html', {'result': result})


def add_designers(request):
    if request.method == "POST":
        form = DesignerForm(request.POST)  
        if form.is_valid():
            constructor = form.save(commit=False)
            constructor.save()  
            messages.success(request, "Designer user added successfully.")
            return redirect('designers')  
        else:
            messages.error(request, "There was an error with your submission.")
    else:
        form = DesignerForm()

    return render(request, 'add_designers.html', {'form': form})


def delete_designers(request, id):
    designer = get_object_or_404(Designers, id=id)
    
    if request.method == "POST":
        # Delete the record
        designer.delete()
        messages.success(request, "Designer record deleted successfully!")
        return redirect('designers')  
    # a GET request (e.g. typing the URL) must also return a response
    return redirect('designers')


# # list the workers in contract side.
def workers(request):
    result = Employees.objects.all()
    return render(request, 'list_workers.html', {'result': result})


# add workers.
def add_workers(request):
    if request.method == "POST":
        form = WorkerForm(request.POST, request.FILES)  
        if form.is_valid():
            constructor = form.save(commit=False)
            constructor.save()  
            messages.success(request, "Employee added successfully.")
            return redirect('workers')  
        else:
            messages.error(request, "There was an error with your submission.")
    else:
        form = WorkerForm()

    return render(request, 'add_workers.html', {'form': form})


def delete_workers(request, id):
    worker = get_object_or_404(Employees, id=id)
    
    if request.method == "POST":
        worker.delete()
        messages.success(request, "Employee record deleted successfully!")
        return redirect('workers')
    # a GET request (e.g. typing the URL) must also return a response
    return redirect('workers')
    

def user_requirements(request):
    result = ProjectRequirements.objects.filter(designer_id=request.session.get('d_id'))
    user = TableUser.objects.all()
    contractor = Contractors.objects.all()
    for i in result:
        for j in user:
            if str(i.user_id)==str(j.id):
                i.user_id=j.name
    
    for i in result:
        for j in contractor:
            if str(i.contractor_id)==str(j.id):
                i.contractor_id=j.name
    return render(request, 'requirements.html', {'result': result})


def accept_requirements(request, id):
    result = get_object_or_404(ProjectRequirements, id=id)
    result.requirement_status = "Accepted"
    result.save()
    return redirect('user_requirements')


def add_plan(request, id):
    result = get_object_or_404(ProjectRequirements, id=id)
    contractors  = Contractors.objects.all()
    if request.method == "POST":
        contractor_id = request.POST.get('contractor')
        plan = request.FILES.get('plan_file')
        print('ddddddddddddddddddddddddddd', plan)

        # contractor_id = get_object_or_404(Contractors, id=contractor)

    
        if contractor_id:
            result.contractor_id = contractor_id 
        result.plan_file = plan
        result.requirement_status = "Plan Submitted"
        result.save()
        return redirect('user_requirements')
    
    return render(request, 'add_plan.html', {'contractors': contractors, 'result': result })


def designs(request):
    result = DesignersWork.objects.filter(designer_id=request.session.get('d_id'))
    return render(request, 'designs.html', {'result': result})


def add_designs(request):
    if request.method == "POST":
        form = DesignForm(request.POST, request.FILES)  
        if form.is_valid():
            constructor = form.save(commit=False)
            constructor.designer_id = request.session.get('d_id')
            constructor.save()  
            messages.success(request, "Designs added successfully.")
            return redirect('designs')  
        else:
            messages.error(request, "There was an error with your submission.")
    else:
        form = DesignForm()

    return render(request, 'add_designs.html', {'form': form})


def delete_designs(request, id):
    designer = get_object_or_404(DesignersWork, id=id)
    
    if request.method == "POST":
        # Delete the record
        designer.delete()
        messages.success(request, "Designs record deleted successfully!")
        return redirect('designs')  
    # a GET request (e.g. typing the URL) must also return a response
    return redirect('designs')


def payments(request):
    result = WeeklyPayments.objects.filter(status="paid")
    return render(request, 'payments.html', {'result': result})

def show_project_requirements(request):
    """Admin 'Plan details' page: every project with its client, contractor and plan file.

    Uses ProjectRequirements (text columns, same as the rest of the app) so empty or
    non-numeric values can no longer crash the page, and never calls .url on a missing
    file (that raised ValueError and gave the error page).
    """
    if not request.user.is_authenticated or not request.user.is_superuser:
        return redirect('/portal/login/?role=admin')

    clients = {str(u.id): u.name for u in TableUser.objects.all()}
    contractors = {str(c.id): c.name for c in Contractors.objects.all()}
    image_exts = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg')

    rows = []
    for req in ProjectRequirements.objects.all().order_by('-id'):
        plan_url, is_image = None, False
        if req.plan_file:
            try:
                plan_url = req.plan_file.url
                is_image = str(req.plan_file.name).lower().endswith(image_exts)
            except ValueError:
                plan_url = None
        rows.append({
            'req': req,
            'client': clients.get(str(req.user_id), '-'),
            'contractor': contractors.get(str(req.contractor_id), 'Not assigned'),
            'plan_url': plan_url,
            'is_image': is_image,
        })
    return render(request, 'project_requirements.html', {'rows': rows})
