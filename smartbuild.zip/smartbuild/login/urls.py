from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    path('login/', views.login, name='login'),
    path('logout/', views.signout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    path('contractor/', views.contractor, name='contractor'),
    path('add/contractor/', views.add_contractor, name='add_contractor'),
    path('delete/contractor/<int:id>/', views.delete_contractor, name='delete_contractor'),

    path('designers/', views.designers, name='designers'),
    path('add/designers/', views.add_designers, name='add_designers'),
    path('delete/designers/<int:id>/', views.delete_designers, name='delete_designers'),

    path('workers/', views.workers, name='workers'),
    path('add/workers/', views.add_workers, name='add_workers'),
    path('delete/workers/<int:id>/', views.delete_workers, name='delete_workers'),

    path('user_requirements/', views.user_requirements, name='user_requirements'),
    path('accept_requirements/<int:id>/', views.accept_requirements, name='accept_requirements'),
    path('add_plan/<int:id>/', views.add_plan, name='add_plan'),

    path('payments/', views.payments, name='payments'),

    path('requirements/', views.show_project_requirements, name='project_requirements'),

    path('designs/', views.designs, name='designs'),
    path('add/designs/', views.add_designs, name='add_designs'),
    path('delete/designs/<int:id>/', views.delete_designs, name='delete_designs'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)