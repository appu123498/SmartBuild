-- Smart Build Assistant: database changes
-- Compatible with MySQL 5.6 (the version in your dump) - hence no "IF NOT EXISTS" on columns.
-- RUN ONCE, in phpMyAdmin: select database `construction_management` -> SQL tab -> paste -> Go.
-- (Running the ALTER statements a second time fails with "Duplicate column name"; that is harmless.)

-- 1) New table: saved AI cost estimates ---------------------------------------
CREATE TABLE IF NOT EXISTS `tbl_cost_estimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirement_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `budget` decimal(12,2) DEFAULT NULL,
  `predicted_cost` decimal(12,2) NOT NULL,
  `min_cost` decimal(12,2) NOT NULL,
  `max_cost` decimal(12,2) NOT NULL,
  `feasibility` varchar(20) DEFAULT NULL,
  `feasibility_note` varchar(500) DEFAULT NULL,
  `suggested_sq_ft` int(11) DEFAULT NULL,
  `model_version` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_estimate_requirement` (`requirement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) New table: payment milestones ---------------------------------------------
CREATE TABLE IF NOT EXISTS `tbl_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requirement_id` int(11) NOT NULL,
  `seq` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `percent_of_cost` decimal(5,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',   -- Pending / In Progress / Completed / Approved
  `rejection_note` varchar(255) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_milestone_seq` (`requirement_id`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3) Daily updates: link to a milestone + original text + AI summary ---
ALTER TABLE `tbl_plan_daily_updates`
  ADD COLUMN `milestone_id` int(11) DEFAULT NULL,
  ADD COLUMN `transcript` text,
  ADD COLUMN `summary` text;

-- 4) Payments: link a payment to the milestone that triggered it ------------------
ALTER TABLE `tbl_weekly_payments`
  ADD COLUMN `milestone_id` int(11) DEFAULT NULL;

-- To undo everything (only if you need to):
--   DROP TABLE `tbl_cost_estimates`; DROP TABLE `tbl_milestones`;
--   ALTER TABLE `tbl_plan_daily_updates` DROP COLUMN `milestone_id`, DROP COLUMN `transcript`, DROP COLUMN `summary`;
--   ALTER TABLE `tbl_weekly_payments` DROP COLUMN `milestone_id`;
