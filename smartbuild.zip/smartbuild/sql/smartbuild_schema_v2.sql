-- Smart Build Assistant, update 2: payment details for the "Pay now" checkout
-- MySQL 5.6 compatible. RUN ONCE in phpMyAdmin (database `construction_management` -> SQL tab).
-- Run sql/smartbuild_schema.sql first if you have not already.

ALTER TABLE `tbl_weekly_payments`
  ADD COLUMN `method` varchar(30) DEFAULT NULL,
  ADD COLUMN `txn_ref` varchar(40) DEFAULT NULL,
  ADD COLUMN `paid_at` datetime DEFAULT NULL;

-- To undo:  ALTER TABLE `tbl_weekly_payments` DROP COLUMN `method`, DROP COLUMN `txn_ref`, DROP COLUMN `paid_at`;
