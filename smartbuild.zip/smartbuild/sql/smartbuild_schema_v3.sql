-- Smart Build Assistant, update 3: labour / material charges raised by the contractor
-- (payments that are not tied to one of the 5 fixed stages, e.g. extra labour or materials).
-- MySQL 5.6 compatible. RUN ONCE in phpMyAdmin (database `construction_management` -> SQL tab).
-- Run sql/smartbuild_schema.sql and sql/smartbuild_schema_v2.sql first if you have not already.

ALTER TABLE `tbl_weekly_payments`
  ADD COLUMN `category` varchar(20) NOT NULL DEFAULT 'milestone',  
  ADD COLUMN `label` varchar(150) DEFAULT NULL;                    -- e.g. "Labour: site clearing (4 workers, 2 days)"

-- To undo:  ALTER TABLE `tbl_weekly_payments` DROP COLUMN `category`, DROP COLUMN `label`;
